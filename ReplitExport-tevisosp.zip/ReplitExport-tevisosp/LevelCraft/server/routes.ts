import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Level management routes
  
  // Get all levels
  app.get("/api/levels", async (req, res) => {
    try {
      const levels = await storage.getAllLevels();
      res.json(levels);
    } catch (error) {
      console.error("Error fetching levels:", error);
      res.status(500).json({ error: "Failed to fetch levels" });
    }
  });

  // Get specific level
  app.get("/api/levels/:id", async (req, res) => {
    try {
      const level = await storage.getLevel(req.params.id);
      if (!level) {
        return res.status(404).json({ error: "Level not found" });
      }
      
      // Increment play count
      await storage.incrementPlayCount(req.params.id);
      
      res.json(level);
    } catch (error) {
      console.error("Error fetching level:", error);
      res.status(500).json({ error: "Failed to fetch level" });
    }
  });

  // Create or update level
  app.post("/api/levels", async (req, res) => {
    try {
      const level = req.body;
      
      // Basic validation
      if (!level.name || !level.elements || !level.playerStart) {
        return res.status(400).json({ error: "Invalid level data" });
      }

      // Ensure level has an ID
      if (!level.id) {
        level.id = Date.now().toString();
      }

      // Add metadata
      level.created = level.created || new Date().toISOString();
      level.modified = new Date().toISOString();
      level.plays = level.plays || 0;
      level.rating = level.rating || 0;

      const savedLevel = await storage.saveLevel(level);
      res.json(savedLevel);
    } catch (error) {
      console.error("Error saving level:", error);
      res.status(500).json({ error: "Failed to save level" });
    }
  });

  // Delete level
  app.delete("/api/levels/:id", async (req, res) => {
    try {
      const success = await storage.deleteLevel(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Level not found" });
      }
      res.json({ message: "Level deleted successfully" });
    } catch (error) {
      console.error("Error deleting level:", error);
      res.status(500).json({ error: "Failed to delete level" });
    }
  });

  // Rate level
  app.post("/api/levels/:id/rate", async (req, res) => {
    try {
      const { rating } = req.body;
      
      if (typeof rating !== 'number' || rating < 1 || rating > 5) {
        return res.status(400).json({ error: "Rating must be between 1 and 5" });
      }

      const success = await storage.rateLevel(req.params.id, rating);
      if (!success) {
        return res.status(404).json({ error: "Level not found" });
      }

      res.json({ message: "Rating saved successfully" });
    } catch (error) {
      console.error("Error rating level:", error);
      res.status(500).json({ error: "Failed to save rating" });
    }
  });

  // Get popular levels
  app.get("/api/levels/popular", async (req, res) => {
    try {
      const levels = await storage.getPopularLevels();
      res.json(levels);
    } catch (error) {
      console.error("Error fetching popular levels:", error);
      res.status(500).json({ error: "Failed to fetch popular levels" });
    }
  });

  // Search levels
  app.get("/api/levels/search", async (req, res) => {
    try {
      const { q, author, difficulty } = req.query;
      const levels = await storage.searchLevels({
        query: q as string,
        author: author as string,
        difficulty: difficulty as string
      });
      res.json(levels);
    } catch (error) {
      console.error("Error searching levels:", error);
      res.status(500).json({ error: "Failed to search levels" });
    }
  });

  // Level sharing - generate shareable URL
  app.post("/api/levels/:id/share", async (req, res) => {
    try {
      const level = await storage.getLevel(req.params.id);
      if (!level) {
        return res.status(404).json({ error: "Level not found" });
      }

      const shareId = await storage.createShareLink(req.params.id);
      const shareUrl = `${req.protocol}://${req.get('host')}/play/${shareId}`;
      
      res.json({ shareId, shareUrl });
    } catch (error) {
      console.error("Error creating share link:", error);
      res.status(500).json({ error: "Failed to create share link" });
    }
  });

  // Access shared level
  app.get("/api/share/:shareId", async (req, res) => {
    try {
      const level = await storage.getLevelByShareId(req.params.shareId);
      if (!level) {
        return res.status(404).json({ error: "Shared level not found" });
      }

      // Increment play count for shared access
      await storage.incrementPlayCount(level.id);
      
      res.json(level);
    } catch (error) {
      console.error("Error fetching shared level:", error);
      res.status(500).json({ error: "Failed to fetch shared level" });
    }
  });

  // Level statistics
  app.get("/api/levels/:id/stats", async (req, res) => {
    try {
      const stats = await storage.getLevelStats(req.params.id);
      if (!stats) {
        return res.status(404).json({ error: "Level not found" });
      }
      res.json(stats);
    } catch (error) {
      console.error("Error fetching level stats:", error);
      res.status(500).json({ error: "Failed to fetch level stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
