import { users, type User, type InsertUser, type GameLevel } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Level management methods
  getAllLevels(): Promise<GameLevel[]>;
  getLevel(id: string): Promise<GameLevel | undefined>;
  saveLevel(level: GameLevel): Promise<GameLevel>;
  deleteLevel(id: string): Promise<boolean>;
  incrementPlayCount(id: string): Promise<void>;
  rateLevel(id: string, rating: number): Promise<boolean>;
  getPopularLevels(): Promise<GameLevel[]>;
  searchLevels(query: { query?: string; author?: string; difficulty?: string }): Promise<GameLevel[]>;
  createShareLink(id: string): Promise<string>;
  getLevelByShareId(shareId: string): Promise<GameLevel | undefined>;
  getLevelStats(id: string): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private levels: Map<string, GameLevel>;
  private shareLinks: Map<string, string>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.levels = new Map();
    this.shareLinks = new Map();
    this.currentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Level management methods
  async getAllLevels(): Promise<GameLevel[]> {
    return Array.from(this.levels.values());
  }

  async getLevel(id: string): Promise<GameLevel | undefined> {
    return this.levels.get(id);
  }

  async saveLevel(level: GameLevel): Promise<GameLevel> {
    this.levels.set(level.id, level);
    return level;
  }

  async deleteLevel(id: string): Promise<boolean> {
    return this.levels.delete(id);
  }

  async incrementPlayCount(id: string): Promise<void> {
    const level = this.levels.get(id);
    if (level) {
      level.plays = (level.plays || 0) + 1;
      this.levels.set(id, level);
    }
  }

  async rateLevel(id: string, rating: number): Promise<boolean> {
    const level = this.levels.get(id);
    if (level) {
      const currentRating = level.rating || 0;
      level.rating = (currentRating + rating) / 2;
      this.levels.set(id, level);
      return true;
    }
    return false;
  }

  async getPopularLevels(): Promise<GameLevel[]> {
    const levels = Array.from(this.levels.values());
    return levels.sort((a, b) => (b.plays || 0) - (a.plays || 0));
  }

  async searchLevels(query: { query?: string; author?: string; difficulty?: string }): Promise<GameLevel[]> {
    const levels = Array.from(this.levels.values());
    return levels.filter(level => {
      if (query.query && !level.name.toLowerCase().includes(query.query.toLowerCase())) {
        return false;
      }
      if (query.author && level.author !== query.author) {
        return false;
      }
      if (query.difficulty && level.difficulty !== query.difficulty) {
        return false;
      }
      return true;
    });
  }

  async createShareLink(id: string): Promise<string> {
    const shareId = `share_${Date.now()}_${Math.random().toString(36).substring(2)}`;
    this.shareLinks.set(shareId, id);
    return shareId;
  }

  async getLevelByShareId(shareId: string): Promise<GameLevel | undefined> {
    const levelId = this.shareLinks.get(shareId);
    if (levelId) {
      return this.levels.get(levelId);
    }
    return undefined;
  }

  async getLevelStats(id: string): Promise<any> {
    const level = this.levels.get(id);
    if (level) {
      return {
        plays: level.plays || 0,
        rating: level.rating || 0,
        created: level.created
      };
    }
    return null;
  }
}

export const storage = new MemStorage();
