import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (existing)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Game levels table
export const levels = pgTable("levels", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  author: text("author").notNull(),
  description: text("description"),
  width: integer("width").notNull().default(1200),
  height: integer("height").notNull().default(800),
  elements: text("elements").notNull(), // JSON string
  player_start: text("player_start").notNull(), // JSON string
  difficulty: text("difficulty", { enum: ["easy", "medium", "hard"] }).default("medium"),
  tags: text("tags"), // Comma-separated tags
  plays: integer("plays").default(0),
  rating: real("rating").default(0),
  rating_count: integer("rating_count").default(0),
  is_public: boolean("is_public").default(true),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow(),
  share_id: text("share_id").unique(), // For shareable links
});

// Level ratings table
export const level_ratings = pgTable("level_ratings", {
  id: serial("id").primaryKey(),
  level_id: integer("level_id").notNull().references(() => levels.id),
  user_id: integer("user_id").references(() => users.id), // Optional for anonymous ratings
  rating: integer("rating").notNull(), // 1-5 stars
  ip_address: text("ip_address"), // Track anonymous ratings by IP
  created_at: timestamp("created_at").defaultNow(),
});

// Level plays/statistics table
export const level_plays = pgTable("level_plays", {
  id: serial("id").primaryKey(),
  level_id: integer("level_id").notNull().references(() => levels.id),
  user_id: integer("user_id").references(() => users.id), // Optional for anonymous plays
  ip_address: text("ip_address"), // Track anonymous plays by IP
  completed: boolean("completed").default(false),
  score: integer("score").default(0),
  coins_collected: integer("coins_collected").default(0),
  play_time: integer("play_time").default(0), // in seconds
  created_at: timestamp("created_at").defaultNow(),
});

// User favorites/bookmarks
export const level_favorites = pgTable("level_favorites", {
  id: serial("id").primaryKey(),
  level_id: integer("level_id").notNull().references(() => levels.id),
  user_id: integer("user_id").notNull().references(() => users.id),
  created_at: timestamp("created_at").defaultNow(),
});

// Comments/feedback on levels
export const level_comments = pgTable("level_comments", {
  id: serial("id").primaryKey(),
  level_id: integer("level_id").notNull().references(() => levels.id),
  user_id: integer("user_id").references(() => users.id), // Optional for anonymous comments
  username: text("username"), // For anonymous comments
  comment: text("comment").notNull(),
  rating: integer("rating"), // Optional rating with comment
  created_at: timestamp("created_at").defaultNow(),
});

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertLevelSchema = createInsertSchema(levels).pick({
  name: true,
  author: true,
  description: true,
  width: true,
  height: true,
  elements: true,
  player_start: true,
  difficulty: true,
  tags: true,
  is_public: true,
});

export const insertLevelRatingSchema = createInsertSchema(level_ratings).pick({
  level_id: true,
  user_id: true,
  rating: true,
  ip_address: true,
});

export const insertLevelPlaySchema = createInsertSchema(level_plays).pick({
  level_id: true,
  user_id: true,
  ip_address: true,
  completed: true,
  score: true,
  coins_collected: true,
  play_time: true,
});

export const insertLevelCommentSchema = createInsertSchema(level_comments).pick({
  level_id: true,
  user_id: true,
  username: true,
  comment: true,
  rating: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Level = typeof levels.$inferSelect;
export type InsertLevel = z.infer<typeof insertLevelSchema>;

export type LevelRating = typeof level_ratings.$inferSelect;
export type InsertLevelRating = z.infer<typeof insertLevelRatingSchema>;

export type LevelPlay = typeof level_plays.$inferSelect;
export type InsertLevelPlay = z.infer<typeof insertLevelPlaySchema>;

export type LevelComment = typeof level_comments.$inferSelect;
export type InsertLevelComment = z.infer<typeof insertLevelCommentSchema>;

// Game-specific types (for frontend use)
export interface GameLevel {
  id: string;
  name: string;
  author?: string;
  description?: string;
  width: number;
  height: number;
  elements: GameElement[];
  playerStart: { x: number; y: number };
  difficulty?: "easy" | "medium" | "hard";
  tags?: string[];
  plays?: number;
  rating?: number;
  created?: string;
  modified?: string;
  shareId?: string;
  shareUrl?: string;
}

export interface GameElement {
  type: 'platform' | 'coin' | 'obstacle' | 'goal' | 'enemy' | 'powerup';
  x: number;
  y: number;
  width: number;
  height: number;
  color?: string;
  properties?: Record<string, any>;
}

// Search interface
export interface LevelSearchQuery {
  query?: string;
  author?: string;
  difficulty?: string;
  tags?: string[];
  limit?: number;
  offset?: number;
  sortBy?: 'created' | 'plays' | 'rating' | 'name';
  sortOrder?: 'asc' | 'desc';
}

// Level statistics
export interface LevelStats {
  totalPlays: number;
  totalCompletions: number;
  averageScore: number;
  averagePlayTime: number;
  completionRate: number;
  averageRating: number;
  totalRatings: number;
}
