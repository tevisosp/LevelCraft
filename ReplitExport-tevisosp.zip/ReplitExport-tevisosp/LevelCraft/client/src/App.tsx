import { useState, useEffect } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import "@fontsource/inter";
import "./index.css";

// Import our game components
import Menu from "./components/ui/Menu";
import GameCanvas from "./components/game/GameCanvas";
import LevelEditor from "./components/editor/LevelEditor";
import LevelBrowser from "./components/ui/LevelBrowser";
import GameUI from "./components/ui/GameUI";
import { ChessGame } from "./components/chess/ChessGame";

// Import stores
import { useGame } from "./lib/stores/useGame";
import { useAudio } from "./lib/stores/useAudio";

// Game modes
type GameMode = "menu" | "play" | "editor" | "browser" | "chess";

// Query client for server communication
const queryClient = new QueryClient();

function App() {
  const [gameMode, setGameMode] = useState<GameMode>("menu");
  const [currentLevel, setCurrentLevel] = useState<string | null>(null);
  const { phase } = useGame();
  const { isMuted } = useAudio();

  // Initialize audio on first user interaction
  useEffect(() => {
    const initAudio = () => {
      // Audio initialization will be handled by individual components
      document.removeEventListener('click', initAudio);
      document.removeEventListener('keydown', initAudio);
    };

    document.addEventListener('click', initAudio);
    document.addEventListener('keydown', initAudio);

    return () => {
      document.removeEventListener('click', initAudio);
      document.removeEventListener('keydown', initAudio);
    };
  }, []);

  const handleModeChange = (mode: GameMode, levelId?: string) => {
    setGameMode(mode);
    if (levelId) {
      setCurrentLevel(levelId);
    }
  };

  const handleBackToMenu = () => {
    setGameMode("menu");
    setCurrentLevel(null);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ 
        width: '100vw', 
        height: '100vh', 
        position: 'relative', 
        overflow: 'hidden',
        background: 'linear-gradient(to bottom, #87CEEB, #98FB98)'
      }}>
        
        {/* Audio indicator */}
        <div className="absolute top-4 right-4 z-50">
          <button
            onClick={() => useAudio.getState().toggleMute()}
            className="bg-black bg-opacity-50 text-white p-2 rounded"
          >
            {isMuted ? "🔇" : "🔊"}
          </button>
        </div>

        {/* Main game modes */}
        {gameMode === "menu" && (
          <Menu onModeChange={handleModeChange} />
        )}

        {gameMode === "play" && (
          <>
            <GameCanvas levelId={currentLevel} onBack={handleBackToMenu} />
            <GameUI />
          </>
        )}

        {gameMode === "editor" && (
          <LevelEditor onBack={handleBackToMenu} onPlayTest={(levelId) => handleModeChange("play", levelId)} />
        )}

        {gameMode === "browser" && (
          <LevelBrowser onBack={handleBackToMenu} onPlayLevel={(levelId) => handleModeChange("play", levelId)} />
        )}

        {gameMode === "chess" && (
          <ChessGame onBack={handleBackToMenu} />
        )}

      </div>
    </QueryClientProvider>
  );
}

export default App;
