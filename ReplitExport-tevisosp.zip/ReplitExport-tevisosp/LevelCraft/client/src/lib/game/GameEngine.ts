import { GameLevel, GameElement } from '../types/GameTypes';
import { usePlayerStore } from '../stores/usePlayerStore';
import { Physics } from './Physics';
import { CollisionDetection } from './CollisionDetection';
import { renderGameObject } from '../../components/game/GameObject';

export class GameEngine {
  private ctx: CanvasRenderingContext2D;
  private level: GameLevel;
  private physics: Physics;
  private collision: CollisionDetection;
  private camera: { x: number; y: number };
  private lastTime: number;
  private animationTime: number;

  // Callbacks
  public onCollectCoin?: () => void;
  public onLevelComplete?: () => void;
  public onPlayerDeath?: () => void;

  constructor(ctx: CanvasRenderingContext2D, level: GameLevel) {
    this.ctx = ctx;
    this.level = level;
    this.physics = new Physics();
    this.collision = new CollisionDetection();
    this.camera = { x: 0, y: 0 };
    this.lastTime = 0;
    this.animationTime = 0;

    // Initialize player position
    const playerStore = usePlayerStore.getState();
    playerStore.setPosition(level.playerStart.x, level.playerStart.y);
  }

  public handleInput(action: string, pressed: boolean) {
    const playerStore = usePlayerStore.getState();
    
    switch (action) {
      case 'left':
        playerStore.setInput('left', pressed);
        break;
      case 'right':
        playerStore.setInput('right', pressed);
        break;
      case 'jump':
        playerStore.setInput('jump', pressed);
        break;
    }
  }

  public update() {
    const currentTime = performance.now();
    const deltaTime = Math.min((currentTime - this.lastTime) / 1000, 1/30); // Cap at 30fps
    this.lastTime = currentTime;
    this.animationTime += deltaTime;

    const playerStore = usePlayerStore.getState();
    
    // Update physics
    this.physics.updatePlayer(deltaTime);
    
    // Check collisions
    this.checkCollisions();
    
    // Update camera
    this.updateCamera();
    
    // Check win/lose conditions
    this.checkGameState();
  }

  private checkCollisions() {
    const playerStore = usePlayerStore.getState();
    const player = {
      x: playerStore.x,
      y: playerStore.y,
      width: playerStore.width,
      height: playerStore.height,
      velocityX: playerStore.velocityX,
      velocityY: playerStore.velocityY
    };

    let onGround = false;
    const collectedCoins: number[] = [];

    this.level.elements.forEach((element, index) => {
      const collision = this.collision.checkAABB(player, element);
      
      if (collision) {
        switch (element.type) {
          case 'platform':
            // Handle platform collision
            if (player.velocityY > 0 && player.y < element.y) {
              // Landing on top of platform
              playerStore.setPosition(player.x, element.y - player.height);
              playerStore.setVelocity(player.velocityX, 0);
              onGround = true;
            } else if (player.velocityY < 0 && player.y > element.y) {
              // Hitting platform from below
              playerStore.setPosition(player.x, element.y + element.height);
              playerStore.setVelocity(player.velocityX, 0);
            } else if (player.velocityX > 0) {
              // Hitting from left
              playerStore.setPosition(element.x - player.width, player.y);
              playerStore.setVelocity(0, player.velocityY);
            } else if (player.velocityX < 0) {
              // Hitting from right
              playerStore.setPosition(element.x + element.width, player.y);
              playerStore.setVelocity(0, player.velocityY);
            }
            break;

          case 'coin':
            // Collect coin
            collectedCoins.push(index);
            playerStore.collectCoin();
            if (this.onCollectCoin) this.onCollectCoin();
            break;

          case 'obstacle':
            // Take damage
            playerStore.takeDamage(50);
            if (playerStore.health <= 0 && this.onPlayerDeath) {
              this.onPlayerDeath();
            }
            break;

          case 'goal':
            // Level complete
            playerStore.setLevelComplete(true);
            if (this.onLevelComplete) this.onLevelComplete();
            break;

          case 'enemy':
            // Take damage from enemy
            playerStore.takeDamage(25);
            if (playerStore.health <= 0 && this.onPlayerDeath) {
              this.onPlayerDeath();
            }
            break;
        }
      }
    });

    // Remove collected coins
    if (collectedCoins.length > 0) {
      this.level.elements = this.level.elements.filter((_, index) => 
        !collectedCoins.includes(index)
      );
    }

    // Check ground collision (bottom of screen)
    if (player.y + player.height >= this.ctx.canvas.height - 50) {
      playerStore.setPosition(player.x, this.ctx.canvas.height - 50 - player.height);
      playerStore.setVelocity(player.velocityX, 0);
      onGround = true;
    }

    playerStore.setOnGround(onGround);
  }

  private updateCamera() {
    const playerStore = usePlayerStore.getState();
    const canvasWidth = this.ctx.canvas.width;
    const canvasHeight = this.ctx.canvas.height;

    // Follow player with some offset
    const targetX = playerStore.x - canvasWidth / 2;
    const targetY = playerStore.y - canvasHeight / 2;

    // Smooth camera movement
    this.camera.x += (targetX - this.camera.x) * 0.1;
    this.camera.y += (targetY - this.camera.y) * 0.1;

    // Keep camera within level bounds
    this.camera.x = Math.max(0, Math.min(this.camera.x, this.level.width - canvasWidth));
    this.camera.y = Math.max(0, Math.min(this.camera.y, this.level.height - canvasHeight));
  }

  private checkGameState() {
    const playerStore = usePlayerStore.getState();
    
    // Check if player fell off the level
    if (playerStore.y > this.level.height + 100) {
      playerStore.takeDamage(100); // Kill player
      if (this.onPlayerDeath) this.onPlayerDeath();
    }

    // Check if out of lives
    if (playerStore.lives <= 0 && playerStore.health <= 0) {
      if (this.onPlayerDeath) this.onPlayerDeath();
    }
  }

  public render() {
    const ctx = this.ctx;
    const canvasWidth = ctx.canvas.width;
    const canvasHeight = ctx.canvas.height;

    // Clear canvas
    ctx.clearRect(0, 0, canvasWidth, canvasHeight);

    // Save context for camera transform
    ctx.save();
    ctx.translate(-this.camera.x, -this.camera.y);

    // Draw background
    const gradient = ctx.createLinearGradient(0, 0, 0, this.level.height);
    gradient.addColorStop(0, '#87CEEB'); // Sky blue
    gradient.addColorStop(1, '#98FB98'); // Light green
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, this.level.width, this.level.height);

    // Draw grid for debugging (optional)
    if (false) { // Set to true for debugging
      ctx.strokeStyle = '#CCCCCC';
      ctx.lineWidth = 1;
      const gridSize = 40;
      
      for (let x = 0; x <= this.level.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, this.level.height);
        ctx.stroke();
      }
      
      for (let y = 0; y <= this.level.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(this.level.width, y);
        ctx.stroke();
      }
    }

    // Draw level elements
    this.level.elements.forEach((element) => {
      renderGameObject(element, ctx);
    });

    // Draw player
    const playerStore = usePlayerStore.getState();
    this.renderPlayer(ctx, playerStore);

    // Restore context
    ctx.restore();

    // Draw UI elements (not affected by camera)
    this.renderUI(ctx);
  }

  private renderPlayer(ctx: CanvasRenderingContext2D, player: any) {
    ctx.save();

    // Player body
    ctx.fillStyle = '#4A90E2';
    ctx.fillRect(player.x, player.y, player.width, player.height);

    // Simple face
    ctx.fillStyle = '#FFFFFF';
    // Eyes
    ctx.fillRect(player.x + 6, player.y + 8, 4, 4);
    ctx.fillRect(player.x + 20, player.y + 8, 4, 4);
    
    // Mouth
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(player.x + player.width/2, player.y + 20, 6, 0, Math.PI);
    ctx.stroke();

    // Movement animation
    if (player.isMovingLeft || player.isMovingRight) {
      const bounce = Math.sin(this.animationTime * 10) * 2;
      ctx.fillStyle = '#4A90E2';
      ctx.fillRect(player.x, player.y + bounce, player.width, player.height);
    }

    ctx.restore();
  }

  private renderUI(ctx: CanvasRenderingContext2D) {
    // UI is handled by React components, but we can add debug info here
    if (false) { // Set to true for debugging
      const playerStore = usePlayerStore.getState();
      
      ctx.fillStyle = 'black';
      ctx.font = '14px Arial';
      ctx.fillText(`Player: ${Math.round(playerStore.x)}, ${Math.round(playerStore.y)}`, 10, 30);
      ctx.fillText(`Velocity: ${Math.round(playerStore.velocityX)}, ${Math.round(playerStore.velocityY)}`, 10, 50);
      ctx.fillText(`On Ground: ${playerStore.isOnGround}`, 10, 70);
      ctx.fillText(`Camera: ${Math.round(this.camera.x)}, ${Math.round(this.camera.y)}`, 10, 90);
    }
  }

  public reset() {
    // Reset player to starting position
    const playerStore = usePlayerStore.getState();
    playerStore.resetPlayer();
    playerStore.setPosition(this.level.playerStart.x, this.level.playerStart.y);
    
    // Reset camera
    this.camera = { x: 0, y: 0 };
    
    // Reset animation time
    this.animationTime = 0;
    this.lastTime = 0;
  }
}
