import { ChessGameState, Piece, Move, PieceType, PieceColor, Position, PieceRank, RecruitmentAction } from '../types/ChessTypes';
import { ChessEngine } from './ChessEngine';

export class EnhancedChessEngine extends ChessEngine {
  
  // Piece ranking system based on the rules
  private pieceRanks: PieceRank[] = [
    { name: 'Пешки', types: ['pawn'], baseValue: 1, rank: 1 },
    { name: 'Слоны/Кони', types: ['bishop', 'knight'], baseValue: 3, rank: 2 },
    { name: 'Ладьи', types: ['rook'], baseValue: 5, rank: 3 },
    { name: 'Ферзь', types: ['queen'], baseValue: 9, rank: 4 },
    { name: 'Король', types: ['king'], baseValue: 0, rank: 5 }
  ];

  // Generate unique ID for pieces
  private generatePieceId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  // Initialize enhanced board with piece metadata
  public initializeEnhancedBoard(): (Piece | null)[][] {
    const board = this.initializeBoard();
    
    // Add enhanced properties to all pieces
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        if (board[row][col]) {
          const piece = board[row][col]!;
          board[row][col] = {
            ...piece,
            age: 0,
            movesCount: 0,
            capturesCount: 0,
            value: this.getBasePieceValue(piece.type),
            isRecruited: false,
            id: this.generatePieceId()
          };
        }
      }
    }
    
    return board;
  }

  // Get base value for piece type
  private getBasePieceValue(type: PieceType): number {
    const rank = this.pieceRanks.find(r => r.types.includes(type));
    return rank ? rank.baseValue : 0;
  }

  // Get piece rank
  private getPieceRank(type: PieceType): number {
    const rank = this.pieceRanks.find(r => r.types.includes(type));
    return rank ? rank.rank : 0;
  }

  // Check if an older piece can capture a younger piece of the same rank
  public canOldPieceCaptureYoung(attacker: Piece, target: Piece): boolean {
    const attackerRank = this.getPieceRank(attacker.type);
    const targetRank = this.getPieceRank(target.type);
    
    // Different ranks can always capture each other
    if (attackerRank !== targetRank) return true;
    
    // Same rank: older piece cannot capture younger piece
    return attacker.age <= target.age;
  }

  // Calculate recruitment cost based on piece value and properties
  public calculateRecruitmentCost(piece: Piece): number {
    const baseRank = this.getPieceRank(piece.type);
    let cost = piece.value * 2; // Base cost is 2x current value
    
    // More expensive for higher ranks
    cost *= baseRank;
    
    // More expensive for pieces with more captures
    cost += piece.capturesCount * 0.5;
    
    // Discount for older pieces (they're less valuable)
    cost *= Math.max(0.5, 1 - (piece.age * 0.1));
    
    return Math.ceil(cost);
  }

  // Check if piece can be recruited
  public canRecruitPiece(gameState: ChessGameState, position: Position, recruitingPlayer: PieceColor): boolean {
    const piece = gameState.board[position.row][position.col];
    if (!piece || piece.color === recruitingPlayer) return false;
    
    // Must be under attack to be recruited
    return this.isSquareUnderAttack(gameState, position, recruitingPlayer);
  }

  // Helper method to check if square is under attack (override from base class)
  private isSquareUnderAttack(gameState: ChessGameState, position: Position, byColor: PieceColor): boolean {
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = gameState.board[row][col];
        if (piece && piece.color === byColor) {
          if (this.canPieceAttackSquare(gameState, { row, col }, position, piece)) {
            return true;
          }
        }
      }
    }
    return false;
  }

  // Helper method for piece attack validation
  private canPieceAttackSquare(gameState: ChessGameState, from: Position, to: Position, piece: Piece): boolean {
    // For pawns, attack pattern is different from movement
    if (piece.type === 'pawn') {
      const direction = piece.color === 'white' ? -1 : 1;
      const rowDiff = to.row - from.row;
      const colDiff = Math.abs(to.col - from.col);
      return rowDiff === direction && colDiff === 1;
    }
    
    return this.isValidPieceMove(gameState, from, to, piece);
  }

  // Helper method for piece movement validation
  private isValidPieceMove(gameState: ChessGameState, from: Position, to: Position, piece: Piece): boolean {
    const rowDiff = to.row - from.row;
    const colDiff = to.col - from.col;
    const absRowDiff = Math.abs(rowDiff);
    const absColDiff = Math.abs(colDiff);
    
    switch (piece.type) {
      case 'pawn':
        return this.isValidPawnMove(gameState, from, to, piece);
      case 'rook':
        return (rowDiff === 0 || colDiff === 0) && this.isPathClear(gameState, from, to);
      case 'knight':
        return (absRowDiff === 2 && absColDiff === 1) || (absRowDiff === 1 && absColDiff === 2);
      case 'bishop':
        return absRowDiff === absColDiff && this.isPathClear(gameState, from, to);
      case 'queen':
        return ((rowDiff === 0 || colDiff === 0) || (absRowDiff === absColDiff)) && 
               this.isPathClear(gameState, from, to);
      case 'king':
        return absRowDiff <= 1 && absColDiff <= 1;
      default:
        return false;
    }
  }

  // Helper method for pawn movement validation
  private isValidPawnMove(gameState: ChessGameState, from: Position, to: Position, piece: Piece): boolean {
    const direction = piece.color === 'white' ? -1 : 1;
    const startRow = piece.color === 'white' ? 6 : 1;
    const rowDiff = to.row - from.row;
    const colDiff = Math.abs(to.col - from.col);
    
    // Forward moves
    if (colDiff === 0) {
      if (rowDiff === direction && !gameState.board[to.row][to.col]) {
        return true;
      }
      if (from.row === startRow && rowDiff === 2 * direction && 
          !gameState.board[to.row][to.col] && !gameState.board[from.row + direction][from.col]) {
        return true;
      }
    }
    
    // Diagonal captures
    if (colDiff === 1 && rowDiff === direction) {
      const targetPiece = gameState.board[to.row][to.col];
      if (targetPiece && targetPiece.color !== piece.color) {
        return true;
      }
      const enPassantSquare = this.positionToSquare(to);
      if (gameState.enPassantTarget === enPassantSquare) {
        return true;
      }
    }
    
    return false;
  }

  // Helper method for path checking
  private isPathClear(gameState: ChessGameState, from: Position, to: Position): boolean {
    const rowStep = to.row === from.row ? 0 : (to.row > from.row ? 1 : -1);
    const colStep = to.col === from.col ? 0 : (to.col > from.col ? 1 : -1);
    
    let currentRow = from.row + rowStep;
    let currentCol = from.col + colStep;
    
    while (currentRow !== to.row || currentCol !== to.col) {
      if (gameState.board[currentRow][currentCol] !== null) {
        return false;
      }
      currentRow += rowStep;
      currentCol += colStep;
    }
    
    return true;
  }

  // Get all recruitment options for current player
  public getRecruitmentOptions(gameState: ChessGameState): RecruitmentAction[] {
    const options: RecruitmentAction[] = [];
    const currentPlayer = gameState.currentPlayer;
    const playerCapital = gameState.capital[currentPlayer];
    
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const position = { row, col };
        const piece = gameState.board[row][col];
        
        if (piece && this.canRecruitPiece(gameState, position, currentPlayer)) {
          const cost = this.calculateRecruitmentCost(piece);
          const isAvailable = cost <= playerCapital;
          
          options.push({
            targetPiece: piece,
            cost,
            position,
            isAvailable,
            description: `Завербовать ${this.getPieceDisplayName(piece)} за ${cost} капитала`
          });
        }
      }
    }
    
    return options.sort((a, b) => a.cost - b.cost);
  }

  // Get display name for piece
  private getPieceDisplayName(piece: Piece): string {
    const names = {
      'pawn': 'пешку',
      'knight': 'коня',
      'bishop': 'слона',
      'rook': 'ладью',
      'queen': 'ферзя',
      'king': 'короля'
    };
    return names[piece.type] || piece.type;
  }

  // Execute recruitment
  public executeRecruitment(gameState: ChessGameState, action: RecruitmentAction): ChessGameState {
    const newState = this.copyEnhancedGameState(gameState);
    const { position, cost } = action;
    
    // Deduct capital
    newState.capital[gameState.currentPlayer] -= cost;
    
    // Change piece color and mark as recruited
    const piece = newState.board[position.row][position.col];
    if (piece) {
      piece.color = gameState.currentPlayer;
      piece.isRecruited = true;
      piece.recruitmentCost = cost;
      
      // Recruited piece loses some value
      piece.value = Math.max(1, Math.floor(piece.value * 0.7));
    }
    
    return newState;
  }

  // Age all pieces on the board
  public agePieces(gameState: ChessGameState): ChessGameState {
    const newState = this.copyEnhancedGameState(gameState);
    
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = newState.board[row][col];
        if (piece) {
          // Pieces that moved recently age slower
          if (piece.movesCount > 0) {
            piece.age += 0.5; // Slower aging for active pieces
          } else {
            piece.age += 1; // Normal aging for idle pieces
          }
          
          // Reset moves count for next turn cycle
          piece.movesCount = 0;
        }
      }
    }
    
    return newState;
  }

  // Update piece values based on activity and captures
  public updatePieceValues(gameState: ChessGameState): ChessGameState {
    const newState = this.copyEnhancedGameState(gameState);
    
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = newState.board[row][col];
        if (piece) {
          // Base value
          let newValue = this.getBasePieceValue(piece.type);
          
          // Bonus for captures
          newValue += piece.capturesCount * 0.5;
          
          // Bonus for being active (more moves = higher value)
          const activityBonus = Math.min(2, piece.movesCount * 0.1);
          newValue += activityBonus;
          
          // Penalty for being recruited (already applied during recruitment)
          if (!piece.isRecruited) {
            piece.value = Math.max(1, newValue);
          }
        }
      }
    }
    
    return newState;
  }

  // Enhanced move validation including aging rules
  public isValidEnhancedMove(gameState: ChessGameState, move: Move): boolean {
    // First check standard chess rules
    if (!this.isValidMove(gameState, move)) {
      return false;
    }
    
    const fromPos = this.squareToPosition(move.from);
    const toPos = this.squareToPosition(move.to);
    const attacker = gameState.board[fromPos.row][fromPos.col];
    const target = gameState.board[toPos.row][toPos.col];
    
    // If capturing, check aging rules
    if (target && attacker && target.color !== attacker.color) {
      return this.canOldPieceCaptureYoung(attacker, target);
    }
    
    return true;
  }

  // Enhanced move execution with piece aging and value updates
  public executeEnhancedMove(gameState: ChessGameState, move: Move): ChessGameState {
    const newState = this.copyEnhancedGameState(gameState);
    const fromPos = this.squareToPosition(move.from);
    const toPos = this.squareToPosition(move.to);
    
    const movingPiece = newState.board[fromPos.row][fromPos.col];
    const capturedPiece = newState.board[toPos.row][toPos.col];
    
    if (movingPiece) {
      // Update piece activity
      movingPiece.movesCount += 1;
      movingPiece.age = Math.max(0, movingPiece.age - 0.1); // Active pieces age slower
      
      // If capturing, update capture count and value
      if (capturedPiece && capturedPiece.color !== movingPiece.color) {
        movingPiece.capturesCount += 1;
        movingPiece.value += capturedPiece.value * 0.1; // Gain some value from captures
        
        // Add capital for capturing
        const captureBonus = Math.floor(capturedPiece.value);
        newState.capital[move.player] += captureBonus;
      }
    }
    
    // Execute the basic move
    const baseNewState = this.executeMove(newState, move);
    
    // Age other pieces
    return this.agePieces(baseNewState);
  }

  // Create initial enhanced game state
  public createEnhancedGameState(): ChessGameState {
    return {
      board: this.initializeEnhancedBoard(),
      currentPlayer: 'white',
      moveHistory: [],
      isCheck: false,
      isCheckmate: false,
      isStalemate: false,
      canCastle: {
        white: { kingside: true, queenside: true },
        black: { kingside: true, queenside: true }
      },
      enPassantTarget: undefined,
      halfMoveClock: 0,
      fullMoveNumber: 1,
      gameNumber: 1,
      capital: { white: 5, black: 5 }, // Starting capital
      gameEndOffered: undefined
    };
  }

  // Calculate piece value for selling to capital
  public calculateSellValue(piece: Piece): number {
    if (piece.type === 'king') return 0; // Kings cannot be sold
    
    let sellValue = piece.value * 0.8; // 80% of current value
    
    // Veteran pieces are worth more
    if (piece.capturesCount > 0 || piece.movesCount > 10) {
      sellValue *= 1.2;
    }
    
    return Math.floor(sellValue);
  }

  // Prepare pieces for next game
  public prepareVeteranPieces(pieces: Piece[]): Piece[] {
    return pieces
      .filter(p => p.type !== 'king') // Kings don't carry over
      .map(p => ({
        ...p,
        age: Math.max(0, p.age - 2), // Veterans start younger
        id: this.generatePieceId() // New ID for new game
      }));
  }

  // Copy enhanced game state
  private copyEnhancedGameState(gameState: ChessGameState): ChessGameState {
    return {
      ...gameState,
      board: gameState.board.map(row => 
        row.map(piece => piece ? { ...piece } : null)
      ),
      moveHistory: [...gameState.moveHistory],
      canCastle: {
        white: { ...gameState.canCastle.white },
        black: { ...gameState.canCastle.black }
      },
      capital: { ...gameState.capital }
    };
  }
}