import { usePlayerStore } from '../stores/usePlayerStore';

export class Physics {
  private gravity = 980; // pixels per second squared
  private jumpStrength = 400; // pixels per second
  private moveSpeed = 300; // pixels per second
  private friction = 0.8;
  private airResistance = 0.98;

  public updatePlayer(deltaTime: number) {
    const playerStore = usePlayerStore.getState();
    const { x, y, velocityX, velocityY, inputs, isOnGround } = playerStore;

    let newVelocityX = velocityX;
    let newVelocityY = velocityY;

    // Horizontal movement
    if (inputs.left) {
      newVelocityX = -this.moveSpeed;
    } else if (inputs.right) {
      newVelocityX = this.moveSpeed;
    } else {
      // Apply friction when not moving
      newVelocityX *= isOnGround ? this.friction : this.airResistance;
      if (Math.abs(newVelocityX) < 1) {
        newVelocityX = 0;
      }
    }

    // Jumping
    if (inputs.jump && isOnGround) {
      newVelocityY = -this.jumpStrength;
      playerStore.setOnGround(false);
    }

    // Apply gravity
    if (!isOnGround) {
      newVelocityY += this.gravity * deltaTime;
    }

    // Terminal velocity
    newVelocityY = Math.min(newVelocityY, 1000);

    // Update velocity
    playerStore.setVelocity(newVelocityX, newVelocityY);

    // Update position
    const newX = x + newVelocityX * deltaTime;
    const newY = y + newVelocityY * deltaTime;

    playerStore.setPosition(newX, newY);
  }

  // Helper method to apply impulse (for power-ups, etc.)
  public applyImpulse(impulseX: number, impulseY: number) {
    const playerStore = usePlayerStore.getState();
    const { velocityX, velocityY } = playerStore;
    
    playerStore.setVelocity(
      velocityX + impulseX,
      velocityY + impulseY
    );
  }

  // Check if a position is valid (not inside walls)
  public isPositionValid(x: number, y: number, width: number, height: number): boolean {
    // Simple bounds checking - can be extended with collision detection
    return x >= 0 && y >= 0 && x + width <= 2000 && y + height <= 1500;
  }
}
