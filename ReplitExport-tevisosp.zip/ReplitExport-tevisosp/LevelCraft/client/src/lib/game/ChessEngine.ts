import { ChessGameState, Piece, Move, PieceType, PieceColor, Position } from '../types/ChessTypes';

export class ChessEngine {
  
  // Initialize a standard chess board
  public initializeBoard(): (Piece | null)[][] {
    const board: (Piece | null)[][] = Array(8).fill(null).map(() => Array(8).fill(null));
    
    // Place pawns
    for (let col = 0; col < 8; col++) {
      board[1][col] = { type: 'pawn', color: 'black', hasMoved: false };
      board[6][col] = { type: 'pawn', color: 'white', hasMoved: false };
    }
    
    // Place other pieces
    const pieceOrder: PieceType[] = ['rook', 'knight', 'bishop', 'queen', 'king', 'bishop', 'knight', 'rook'];
    
    for (let col = 0; col < 8; col++) {
      board[0][col] = { type: pieceOrder[col], color: 'black', hasMoved: false };
      board[7][col] = { type: pieceOrder[col], color: 'white', hasMoved: false };
    }
    
    return board;
  }

  // Convert square notation (e.g., "e4") to position
  public squareToPosition(square: string): Position {
    const col = square.charCodeAt(0) - 97; // 'a' = 0, 'b' = 1, etc.
    const row = 8 - parseInt(square[1]);   // '8' = 0, '7' = 1, etc.
    return { row, col };
  }

  // Convert position to square notation
  public positionToSquare(pos: Position): string {
    const col = String.fromCharCode(97 + pos.col);
    const row = (8 - pos.row).toString();
    return col + row;
  }

  // Check if a move is valid
  public isValidMove(gameState: ChessGameState, move: Move): boolean {
    const fromPos = this.squareToPosition(move.from);
    const toPos = this.squareToPosition(move.to);
    const piece = gameState.board[fromPos.row][fromPos.col];
    
    if (!piece || piece.color !== move.player) {
      return false;
    }
    
    // Check if destination has own piece
    const targetPiece = gameState.board[toPos.row][toPos.col];
    if (targetPiece && targetPiece.color === piece.color) {
      return false;
    }
    
    // Check piece-specific movement rules
    if (!this.isValidPieceMove(gameState, fromPos, toPos, piece)) {
      return false;
    }
    
    // Check if move would put own king in check
    if (this.wouldBeInCheck(gameState, move)) {
      return false;
    }
    
    return true;
  }

  // Check if a piece can move to a specific position
  private isValidPieceMove(gameState: ChessGameState, from: Position, to: Position, piece: Piece): boolean {
    const rowDiff = to.row - from.row;
    const colDiff = to.col - from.col;
    const absRowDiff = Math.abs(rowDiff);
    const absColDiff = Math.abs(colDiff);
    
    switch (piece.type) {
      case 'pawn':
        return this.isValidPawnMove(gameState, from, to, piece);
      
      case 'rook':
        return (rowDiff === 0 || colDiff === 0) && this.isPathClear(gameState, from, to);
      
      case 'knight':
        return (absRowDiff === 2 && absColDiff === 1) || (absRowDiff === 1 && absColDiff === 2);
      
      case 'bishop':
        return absRowDiff === absColDiff && this.isPathClear(gameState, from, to);
      
      case 'queen':
        return ((rowDiff === 0 || colDiff === 0) || (absRowDiff === absColDiff)) && 
               this.isPathClear(gameState, from, to);
      
      case 'king':
        return absRowDiff <= 1 && absColDiff <= 1;
      
      default:
        return false;
    }
  }

  // Check if pawn move is valid (including en passant and promotion)
  private isValidPawnMove(gameState: ChessGameState, from: Position, to: Position, piece: Piece): boolean {
    const direction = piece.color === 'white' ? -1 : 1;
    const startRow = piece.color === 'white' ? 6 : 1;
    const rowDiff = to.row - from.row;
    const colDiff = Math.abs(to.col - from.col);
    
    // Forward moves
    if (colDiff === 0) {
      // One square forward
      if (rowDiff === direction && !gameState.board[to.row][to.col]) {
        return true;
      }
      // Two squares forward from starting position
      if (from.row === startRow && rowDiff === 2 * direction && 
          !gameState.board[to.row][to.col] && !gameState.board[from.row + direction][from.col]) {
        return true;
      }
    }
    
    // Diagonal captures
    if (colDiff === 1 && rowDiff === direction) {
      const targetPiece = gameState.board[to.row][to.col];
      if (targetPiece && targetPiece.color !== piece.color) {
        return true;
      }
      
      // En passant
      const enPassantSquare = this.positionToSquare(to);
      if (gameState.enPassantTarget === enPassantSquare) {
        return true;
      }
    }
    
    return false;
  }

  // Check if path between two squares is clear
  private isPathClear(gameState: ChessGameState, from: Position, to: Position): boolean {
    const rowStep = to.row === from.row ? 0 : (to.row > from.row ? 1 : -1);
    const colStep = to.col === from.col ? 0 : (to.col > from.col ? 1 : -1);
    
    let currentRow = from.row + rowStep;
    let currentCol = from.col + colStep;
    
    while (currentRow !== to.row || currentCol !== to.col) {
      if (gameState.board[currentRow][currentCol] !== null) {
        return false;
      }
      currentRow += rowStep;
      currentCol += colStep;
    }
    
    return true;
  }

  // Check if move would put own king in check
  private wouldBeInCheck(gameState: ChessGameState, move: Move): boolean {
    // Create a copy of the game state and apply the move
    const tempState = this.copyGameState(gameState);
    this.applyMoveToState(tempState, move);
    
    // Find the king
    const kingPos = this.findKing(tempState, move.player);
    if (!kingPos) return true; // No king found, invalid state
    
    // Check if any enemy piece can attack the king
    return this.isSquareUnderAttack(tempState, kingPos, move.player === 'white' ? 'black' : 'white');
  }

  // Find king position
  private findKing(gameState: ChessGameState, color: PieceColor): Position | null {
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = gameState.board[row][col];
        if (piece && piece.type === 'king' && piece.color === color) {
          return { row, col };
        }
      }
    }
    return null;
  }

  // Check if a square is under attack by a specific color
  private isSquareUnderAttack(gameState: ChessGameState, position: Position, byColor: PieceColor): boolean {
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = gameState.board[row][col];
        if (piece && piece.color === byColor) {
          if (this.canPieceAttackSquare(gameState, { row, col }, position, piece)) {
            return true;
          }
        }
      }
    }
    return false;
  }

  // Check if a piece can attack a specific square
  private canPieceAttackSquare(gameState: ChessGameState, from: Position, to: Position, piece: Piece): boolean {
    // For pawns, attack pattern is different from movement
    if (piece.type === 'pawn') {
      const direction = piece.color === 'white' ? -1 : 1;
      const rowDiff = to.row - from.row;
      const colDiff = Math.abs(to.col - from.col);
      return rowDiff === direction && colDiff === 1;
    }
    
    return this.isValidPieceMove(gameState, from, to, piece);
  }

  // Apply move to game state (mutates the state)
  private applyMoveToState(gameState: ChessGameState, move: Move): void {
    const fromPos = this.squareToPosition(move.from);
    const toPos = this.squareToPosition(move.to);
    
    gameState.board[toPos.row][toPos.col] = gameState.board[fromPos.row][fromPos.col];
    gameState.board[fromPos.row][fromPos.col] = null;
  }

  // Create a deep copy of game state
  private copyGameState(gameState: ChessGameState): ChessGameState {
    return {
      ...gameState,
      board: gameState.board.map(row => row.map(piece => piece ? { ...piece } : null)),
      moveHistory: [...gameState.moveHistory],
      canCastle: {
        white: { ...gameState.canCastle.white },
        black: { ...gameState.canCastle.black }
      }
    };
  }

  // Get all valid moves for a piece at a given square
  public getValidMoves(gameState: ChessGameState, square: string): string[] {
    const position = this.squareToPosition(square);
    const piece = gameState.board[position.row][position.col];
    
    if (!piece || piece.color !== gameState.currentPlayer) {
      return [];
    }
    
    const validMoves: string[] = [];
    
    // Check all possible destination squares
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const targetSquare = this.positionToSquare({ row, col });
        const move: Move = {
          from: square,
          to: targetSquare,
          piece: piece,
          player: piece.color
        };
        
        if (this.isValidMove(gameState, move)) {
          validMoves.push(targetSquare);
        }
      }
    }
    
    return validMoves;
  }

  // Check if current player is in check
  public isInCheck(gameState: ChessGameState): boolean {
    const kingPos = this.findKing(gameState, gameState.currentPlayer);
    if (!kingPos) return false;
    
    const opponentColor = gameState.currentPlayer === 'white' ? 'black' : 'white';
    return this.isSquareUnderAttack(gameState, kingPos, opponentColor);
  }

  // Check if current player is in checkmate
  public isCheckmate(gameState: ChessGameState): boolean {
    if (!this.isInCheck(gameState)) return false;
    
    // Check if any move can get out of check
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = gameState.board[row][col];
        if (piece && piece.color === gameState.currentPlayer) {
          const square = this.positionToSquare({ row, col });
          const validMoves = this.getValidMoves(gameState, square);
          if (validMoves.length > 0) {
            return false;
          }
        }
      }
    }
    
    return true;
  }

  // Check if current player is in stalemate
  public isStalemate(gameState: ChessGameState): boolean {
    if (this.isInCheck(gameState)) return false;
    
    // Check if player has any valid moves
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = gameState.board[row][col];
        if (piece && piece.color === gameState.currentPlayer) {
          const square = this.positionToSquare({ row, col });
          const validMoves = this.getValidMoves(gameState, square);
          if (validMoves.length > 0) {
            return false;
          }
        }
      }
    }
    
    return true;
  }

  // Execute a move and return the new game state
  public executeMove(gameState: ChessGameState, move: Move): ChessGameState {
    const newState = this.copyGameState(gameState);
    const fromPos = this.squareToPosition(move.from);
    const toPos = this.squareToPosition(move.to);
    
    // Move the piece
    newState.board[toPos.row][toPos.col] = newState.board[fromPos.row][fromPos.col];
    newState.board[fromPos.row][fromPos.col] = null;
    
    // Mark piece as moved
    if (newState.board[toPos.row][toPos.col]) {
      newState.board[toPos.row][toPos.col]!.hasMoved = true;
    }
    
    // Update game state
    newState.currentPlayer = newState.currentPlayer === 'white' ? 'black' : 'white';
    newState.moveHistory.push(move);
    newState.fullMoveNumber = newState.currentPlayer === 'white' ? newState.fullMoveNumber + 1 : newState.fullMoveNumber;
    
    // Update check status
    newState.isCheck = this.isInCheck(newState);
    newState.isCheckmate = this.isCheckmate(newState);
    newState.isStalemate = this.isStalemate(newState);
    
    return newState;
  }
}