import { GameElement } from '../types/GameTypes';

interface CollisionObject {
  x: number;
  y: number;
  width: number;
  height: number;
}

export class CollisionDetection {
  
  // Axis-Aligned Bounding Box collision detection
  public checkAABB(obj1: CollisionObject, obj2: CollisionObject): boolean {
    return (
      obj1.x < obj2.x + obj2.width &&
      obj1.x + obj1.width > obj2.x &&
      obj1.y < obj2.y + obj2.height &&
      obj1.y + obj1.height > obj2.y
    );
  }

  // Get collision side (useful for determining how objects should react)
  public getCollisionSide(moving: CollisionObject, stationary: CollisionObject): string {
    const centerX1 = moving.x + moving.width / 2;
    const centerY1 = moving.y + moving.height / 2;
    const centerX2 = stationary.x + stationary.width / 2;
    const centerY2 = stationary.y + stationary.height / 2;

    const deltaX = centerX1 - centerX2;
    const deltaY = centerY1 - centerY2;

    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);

    if (absX > absY) {
      return deltaX > 0 ? 'right' : 'left';
    } else {
      return deltaY > 0 ? 'bottom' : 'top';
    }
  }

  // Check collision and return penetration depth
  public getCollisionDepth(obj1: CollisionObject, obj2: CollisionObject): { x: number; y: number } {
    if (!this.checkAABB(obj1, obj2)) {
      return { x: 0, y: 0 };
    }

    const overlapX = Math.min(
      obj1.x + obj1.width - obj2.x,
      obj2.x + obj2.width - obj1.x
    );

    const overlapY = Math.min(
      obj1.y + obj1.height - obj2.y,
      obj2.y + obj2.height - obj1.y
    );

    return { x: overlapX, y: overlapY };
  }

  // Point-in-rectangle collision
  public pointInRect(pointX: number, pointY: number, rect: CollisionObject): boolean {
    return (
      pointX >= rect.x &&
      pointX <= rect.x + rect.width &&
      pointY >= rect.y &&
      pointY <= rect.y + rect.height
    );
  }

  // Circle collision detection (for coins, etc.)
  public checkCircleCollision(
    x1: number, y1: number, r1: number,
    x2: number, y2: number, r2: number
  ): boolean {
    const distance = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
    return distance < r1 + r2;
  }

  // Line-rectangle intersection (for raycasting, etc.)
  public lineRectCollision(
    x1: number, y1: number, x2: number, y2: number,
    rect: CollisionObject
  ): boolean {
    // Check if line is completely outside rectangle
    if ((x1 < rect.x && x2 < rect.x) ||
        (x1 > rect.x + rect.width && x2 > rect.x + rect.width) ||
        (y1 < rect.y && y2 < rect.y) ||
        (y1 > rect.y + rect.height && y2 > rect.y + rect.height)) {
      return false;
    }

    // Simplified line-rectangle intersection
    // For a full implementation, you'd need to check line segments against each edge
    return this.pointInRect(x1, y1, rect) || this.pointInRect(x2, y2, rect);
  }

  // Get all collisions for an object against a list of elements
  public getAllCollisions(obj: CollisionObject, elements: GameElement[]): GameElement[] {
    return elements.filter(element => this.checkAABB(obj, element));
  }

  // Sweep collision detection (for fast-moving objects)
  public sweepAABB(
    obj: CollisionObject,
    velocityX: number,
    velocityY: number,
    target: CollisionObject,
    deltaTime: number
  ): { hit: boolean; time: number } {
    // Simplified sweep test
    const futureX = obj.x + velocityX * deltaTime;
    const futureY = obj.y + velocityY * deltaTime;
    
    const futureObj = {
      x: futureX,
      y: futureY,
      width: obj.width,
      height: obj.height
    };

    const hit = this.checkAABB(futureObj, target);
    
    if (hit) {
      // Calculate approximate collision time
      // This is a simplified version - a full implementation would use
      // more sophisticated algorithms
      const time = 0.5; // Assume collision happens halfway through the movement
      return { hit: true, time };
    }

    return { hit: false, time: 1.0 };
  }
}
