import { create } from 'zustand';
import { GameLevel } from '../types/GameTypes';

interface LevelState {
  currentLevel: GameLevel | null;
  levels: GameLevel[];
  
  // Actions
  setCurrentLevel: (level: GameLevel) => void;
  loadLevel: (levelId: string) => Promise<void>;
  saveLevel: (level: GameLevel) => Promise<void>;
  deleteLevel: (levelId: string) => Promise<void>;
  loadLevelsList: () => Promise<GameLevel[]>;
  saveLevelRating: (levelId: string, rating: number) => Promise<void>;
}

export const useLevelStore = create<LevelState>((set, get) => ({
  currentLevel: null,
  levels: [],

  setCurrentLevel: (level) => set({ currentLevel: level }),

  loadLevel: async (levelId) => {
    try {
      // First try to load from localStorage
      const savedLevel = localStorage.getItem(`level_${levelId}`);
      if (savedLevel) {
        const level = JSON.parse(savedLevel);
        set({ currentLevel: level });
        return;
      }

      // Then try to load from server
      const response = await fetch(`/api/levels/${levelId}`);
      if (response.ok) {
        const level = await response.json();
        set({ currentLevel: level });
      } else {
        console.warn(`Level ${levelId} not found`);
      }
    } catch (error) {
      console.error('Failed to load level:', error);
    }
  },

  saveLevel: async (level) => {
    try {
      // Save to localStorage
      localStorage.setItem(`level_${level.id}`, JSON.stringify(level));

      // Also try to save to server
      try {
        await fetch('/api/levels', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(level)
        });
      } catch (serverError) {
        console.warn('Failed to save to server, but saved locally:', serverError);
      }

      // Update levels list
      const { levels } = get();
      const existingIndex = levels.findIndex(l => l.id === level.id);
      if (existingIndex >= 0) {
        levels[existingIndex] = level;
      } else {
        levels.push(level);
      }
      
      set({ levels: [...levels], currentLevel: level });
    } catch (error) {
      console.error('Failed to save level:', error);
      throw error;
    }
  },

  deleteLevel: async (levelId) => {
    try {
      // Remove from localStorage
      localStorage.removeItem(`level_${levelId}`);

      // Try to remove from server
      try {
        await fetch(`/api/levels/${levelId}`, { method: 'DELETE' });
      } catch (serverError) {
        console.warn('Failed to delete from server:', serverError);
      }

      // Update levels list
      const { levels } = get();
      set({ levels: levels.filter(l => l.id !== levelId) });
    } catch (error) {
      console.error('Failed to delete level:', error);
      throw error;
    }
  },

  loadLevelsList: async () => {
    try {
      // Load from localStorage
      const localLevels: GameLevel[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith('level_')) {
          try {
            const level = JSON.parse(localStorage.getItem(key) || '');
            if (level && level.id) {
              localLevels.push(level);
            }
          } catch (e) {
            console.warn('Failed to parse local level:', key);
          }
        }
      }

      // Try to load from server
      let serverLevels: GameLevel[] = [];
      try {
        const response = await fetch('/api/levels');
        if (response.ok) {
          serverLevels = await response.json();
        }
      } catch (serverError) {
        console.warn('Failed to load from server:', serverError);
      }

      // Combine and deduplicate
      const allLevels = [...localLevels];
      serverLevels.forEach(serverLevel => {
        if (!allLevels.find(l => l.id === serverLevel.id)) {
          allLevels.push(serverLevel);
        }
      });

      set({ levels: allLevels });
      return allLevels;
    } catch (error) {
      console.error('Failed to load levels list:', error);
      return [];
    }
  },

  saveLevelRating: async (levelId, rating) => {
    try {
      // Try to save rating to server
      await fetch(`/api/levels/${levelId}/rate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating })
      });

      // Update local level if it exists
      const { levels } = get();
      const updatedLevels = levels.map(level => {
        if (level.id === levelId) {
          const currentRating = level.rating || 0;
          const newRating = (currentRating + rating) / 2;
          return { ...level, rating: newRating };
        }
        return level;
      });
      
      set({ levels: updatedLevels });
    } catch (error) {
      console.error('Failed to save rating:', error);
    }
  }
}));
