import { create } from 'zustand';

interface PlayerState {
  // Position and movement
  x: number;
  y: number;
  velocityX: number;
  velocityY: number;
  width: number;
  height: number;
  
  // Player state
  health: number;
  lives: number;
  score: number;
  coins: number;
  isOnGround: boolean;
  isMovingLeft: boolean;
  isMovingRight: boolean;
  isJumping: boolean;
  levelComplete: boolean;
  
  // Input state
  inputs: {
    left: boolean;
    right: boolean;
    jump: boolean;
  };
  
  // Actions
  setPosition: (x: number, y: number) => void;
  setVelocity: (vx: number, vy: number) => void;
  setOnGround: (onGround: boolean) => void;
  takeDamage: (damage: number) => void;
  heal: (amount: number) => void;
  addScore: (points: number) => void;
  collectCoin: () => void;
  loseLife: () => void;
  setInput: (input: keyof PlayerState['inputs'], pressed: boolean) => void;
  setLevelComplete: (complete: boolean) => void;
  resetPlayer: () => void;
}

const initialState = {
  x: 50,
  y: 500,
  velocityX: 0,
  velocityY: 0,
  width: 30,
  height: 40,
  health: 100,
  lives: 3,
  score: 0,
  coins: 0,
  isOnGround: false,
  isMovingLeft: false,
  isMovingRight: false,
  isJumping: false,
  levelComplete: false,
  inputs: {
    left: false,
    right: false,
    jump: false
  }
};

export const usePlayerStore = create<PlayerState>((set, get) => ({
  ...initialState,

  setPosition: (x, y) => set({ x, y }),
  
  setVelocity: (vx, vy) => set({ velocityX: vx, velocityY: vy }),
  
  setOnGround: (onGround) => set({ isOnGround: onGround }),
  
  takeDamage: (damage) => {
    const { health } = get();
    const newHealth = Math.max(0, health - damage);
    set({ health: newHealth });
    
    if (newHealth <= 0) {
      get().loseLife();
    }
  },
  
  heal: (amount) => {
    const { health } = get();
    set({ health: Math.min(100, health + amount) });
  },
  
  addScore: (points) => {
    const { score } = get();
    set({ score: score + points });
  },
  
  collectCoin: () => {
    const { coins, score } = get();
    set({ 
      coins: coins + 1, 
      score: score + 100 
    });
  },
  
  loseLife: () => {
    const { lives } = get();
    if (lives > 0) {
      set({ 
        lives: lives - 1,
        health: 100 // Restore health when losing a life
      });
    }
  },
  
  setInput: (input, pressed) => {
    const { inputs } = get();
    set({ 
      inputs: { ...inputs, [input]: pressed },
      isMovingLeft: input === 'left' ? pressed : inputs.left,
      isMovingRight: input === 'right' ? pressed : inputs.right,
      isJumping: input === 'jump' ? pressed : inputs.jump
    });
  },
  
  setLevelComplete: (complete) => set({ levelComplete: complete }),
  
  resetPlayer: () => set(initialState)
}));
