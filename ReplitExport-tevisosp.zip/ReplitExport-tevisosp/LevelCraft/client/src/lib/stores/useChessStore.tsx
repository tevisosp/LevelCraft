import { create } from 'zustand';
import { ChessGameState, ChessStore, Move, PieceColor, Piece, GameRules, PlayerInfo, RecruitmentAction, GameCampaign } from '../types/ChessTypes';
import { EnhancedChessEngine } from '../game/EnhancedChessEngine';

const engine = new EnhancedChessEngine();

const defaultGameRules: GameRules = {
  enableEnPassant: true,
  enableCastling: true,
  enablePromotion: true,
  pieceValues: {
    pawn: 1,
    knight: 3,
    bishop: 3,
    rook: 5,
    queen: 9,
    king: 0
  },
  specialMoves: {
    knightCanJumpOverPieces: true,
    bishopCanMoveOneSquare: true,
    rookCanMoveOneSquare: true,
    queenCanTeleport: false,
    kingCanMoveTwo: false,
    pawnCanMoveThree: false
  },
  timeControl: {
    enabled: false,
    initialTime: 600, // 10 minutes
    increment: 10 // 10 seconds per move
  },
  boardModifications: {
    size: { rows: 8, cols: 8 },
    obstacles: [],
    portals: []
  }
};

const createInitialGameState = (): ChessGameState => engine.createEnhancedGameState();

const createInitialPlayerInfo = (color: PieceColor): PlayerInfo => ({
  name: color === 'white' ? 'Белые' : 'Черные',
  color,
  timeRemaining: 600,
  capturedPieces: [],
  score: 0,
  capital: 5, // Starting capital
  veteranPieces: []
});

const createInitialCampaign = (): GameCampaign => ({
  games: [],
  currentGameIndex: 0,
  totalCapital: { white: 5, black: 5 },
  veteranPieces: { white: [], black: [] },
  campaignHistory: []
});

export const useChessStore = create<ChessStore>((set, get) => ({
  gameState: createInitialGameState(),
  currentPlayer: 'white',
  selectedSquare: null,
  validMoves: [],
  recruitmentOptions: [],
  gameHistory: [],
  capturedPieces: { white: [], black: [] },
  isGameOver: false,
  winner: null,
  players: {
    white: createInitialPlayerInfo('white'),
    black: createInitialPlayerInfo('black')
  },
  gameRules: defaultGameRules,
  campaign: createInitialCampaign(),
  showRecruitmentUI: false,

  initializeGame: () => {
    const gameState = createInitialGameState();
    set({
      gameState,
      currentPlayer: 'white',
      selectedSquare: null,
      validMoves: [],
      gameHistory: [],
      capturedPieces: { white: [], black: [] },
      isGameOver: false,
      winner: null,
      players: {
        white: createInitialPlayerInfo('white'),
        black: createInitialPlayerInfo('black')
      }
    });
  },

  makeMove: (move: Move) => {
    const state = get();
    
    if (!engine.isValidEnhancedMove(state.gameState, move)) {
      return;
    }

    // Execute the enhanced move
    const newGameState = engine.executeEnhancedMove(state.gameState, move);
    
    // Handle captured pieces
    const fromPos = engine.squareToPosition(move.from);
    const toPos = engine.squareToPosition(move.to);
    const capturedPiece = state.gameState.board[toPos.row][toPos.col];
    
    const newCapturedPieces = { ...state.capturedPieces };
    if (capturedPiece) {
      move.capturedPiece = capturedPiece;
      newCapturedPieces[move.player].push(capturedPiece);
    }

    // Update game history
    const newGameHistory = [...state.gameHistory, move];

    // Check for game over conditions
    const isGameOver = newGameState.isCheckmate || newGameState.isStalemate;
    const winner = newGameState.isCheckmate ? state.currentPlayer : null;

    // Update recruitment options
    const recruitmentOptions = engine.getRecruitmentOptions(newGameState);

    set({
      gameState: newGameState,
      currentPlayer: newGameState.currentPlayer,
      selectedSquare: null,
      validMoves: [],
      recruitmentOptions,
      gameHistory: newGameHistory,
      capturedPieces: newCapturedPieces,
      isGameOver,
      winner
    });
  },

  selectSquare: (square: string) => {
    const state = get();
    const position = engine.squareToPosition(square);
    const piece = state.gameState.board[position.row][position.col];

    // If clicking on a piece of the current player, select it and show valid moves
    if (piece && piece.color === state.currentPlayer) {
      const validMoves = engine.getValidMoves(state.gameState, square);
      set({
        selectedSquare: square,
        validMoves
      });
    } else {
      // If clicking on empty square or opponent piece, try to make a move
      if (state.selectedSquare) {
        const move: Move = {
          from: state.selectedSquare,
          to: square,
          piece: state.gameState.board[engine.squareToPosition(state.selectedSquare).row][engine.squareToPosition(state.selectedSquare).col]!,
          player: state.currentPlayer
        };
        
        if (engine.isValidMove(state.gameState, move)) {
          get().makeMove(move);
        } else {
          set({ selectedSquare: null, validMoves: [] });
        }
      }
    }
  },

  resetGame: () => {
    get().initializeGame();
  },

  undoMove: () => {
    const state = get();
    if (state.gameHistory.length === 0) return;

    // Remove the last move from history
    const newGameHistory = state.gameHistory.slice(0, -1);
    const lastMove = state.gameHistory[state.gameHistory.length - 1];

    // Rebuild game state from history
    let newGameState = createInitialGameState();
    const newCapturedPieces = { white: [], black: [] };

    for (const move of newGameHistory) {
      newGameState = engine.executeMove(newGameState, move);
      if (move.capturedPiece) {
        if (move.player === 'white') {
          newCapturedPieces.white.push(move.capturedPiece);
        } else {
          newCapturedPieces.black.push(move.capturedPiece);
        }
      }
    }

    set({
      gameState: newGameState,
      currentPlayer: newGameState.currentPlayer,
      selectedSquare: null,
      validMoves: [],
      gameHistory: newGameHistory,
      capturedPieces: newCapturedPieces,
      isGameOver: newGameState.isCheckmate || newGameState.isStalemate,
      winner: newGameState.isCheckmate ? (newGameState.currentPlayer === 'white' ? 'black' : 'white') : null
    });
  },

  setGameRules: (rules: Partial<GameRules>) => {
    const state = get();
    set({
      gameRules: { ...state.gameRules, ...rules }
    });
  },

  calculateValidMoves: (square: string) => {
    const state = get();
    return engine.getValidMoves(state.gameState, square);
  },

  // Enhanced chess functions
  initializeCampaign: () => {
    set({
      campaign: createInitialCampaign(),
      gameState: createInitialGameState(),
      gameHistory: [],
      capturedPieces: { white: [], black: [] },
      isGameOver: false,
      winner: null
    });
  },

  recruitPiece: (action: RecruitmentAction) => {
    const state = get();
    const newGameState = engine.executeRecruitment(state.gameState, action);
    const recruitmentOptions = engine.getRecruitmentOptions(newGameState);

    set({
      gameState: newGameState,
      recruitmentOptions,
      showRecruitmentUI: false
    });
  },

  offerGameEnd: () => {
    const state = get();
    const newGameState = { ...state.gameState };
    newGameState.gameEndOffered = state.currentPlayer;
    set({ gameState: newGameState });
  },

  acceptGameEnd: () => {
    const state = get();
    set({
      isGameOver: true,
      winner: null // Draw by agreement
    });
  },

  startNextGame: () => {
    const state = get();
    // Save current game to campaign
    const updatedCampaign = { ...state.campaign };
    updatedCampaign.games.push(state.gameState);
    updatedCampaign.currentGameIndex += 1;

    // Create new game with veteran pieces
    const newGameState = engine.createEnhancedGameState();
    newGameState.gameNumber = updatedCampaign.currentGameIndex + 1;

    set({
      campaign: updatedCampaign,
      gameState: newGameState,
      currentPlayer: 'white',
      selectedSquare: null,
      validMoves: [],
      recruitmentOptions: [],
      gameHistory: [],
      capturedPieces: { white: [], black: [] },
      isGameOver: false,
      winner: null
    });
  },

  sellPieceForCapital: (piece: Piece) => {
    const state = get();
    const sellValue = engine.calculateSellValue(piece);
    const newGameState = { ...state.gameState };
    newGameState.capital[piece.color] += sellValue;

    set({ gameState: newGameState });
  },

  addVeteranPiece: (piece: Piece) => {
    const state = get();
    const updatedCampaign = { ...state.campaign };
    updatedCampaign.veteranPieces[piece.color].push(piece);
    set({ campaign: updatedCampaign });
  },

  calculateRecruitmentCost: (piece: Piece) => {
    return engine.calculateRecruitmentCost(piece);
  },

  agePieces: () => {
    const state = get();
    const newGameState = engine.agePieces(state.gameState);
    set({ gameState: newGameState });
  },

  updatePieceValues: () => {
    const state = get();
    const newGameState = engine.updatePieceValues(state.gameState);
    set({ gameState: newGameState });
  },

  checkCanCapture: (attacker: Piece, target: Piece) => {
    return engine.canOldPieceCaptureYoung(attacker, target);
  }
}));