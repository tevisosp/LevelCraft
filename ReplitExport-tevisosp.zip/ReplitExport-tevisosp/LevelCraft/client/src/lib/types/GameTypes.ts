// Core game element types
export type ElementType = 'platform' | 'coin' | 'obstacle' | 'goal' | 'enemy' | 'powerup';

export interface GameElement {
  type: ElementType;
  x: number;
  y: number;
  width: number;
  height: number;
  color?: string;
  properties?: Record<string, any>; // For custom properties per element type
}

// Player starting position
export interface PlayerStart {
  x: number;
  y: number;
}

// Complete level definition
export interface GameLevel {
  id: string;
  name: string;
  width: number;
  height: number;
  elements: GameElement[];
  playerStart: PlayerStart;
  
  // Optional metadata
  author?: string;
  description?: string;
  difficulty?: 'easy' | 'medium' | 'hard';
  tags?: string[];
  created?: string;
  modified?: string;
  plays?: number;
  rating?: number;
  thumbnail?: string;
}

// Player state interface
export interface Player {
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number;
  velocityY: number;
  health: number;
  lives: number;
  score: number;
  coins: number;
  isOnGround: boolean;
  facingRight: boolean;
}

// Game state types
export type GamePhase = 'ready' | 'playing' | 'paused' | 'ended';

// Input state
export interface InputState {
  left: boolean;
  right: boolean;
  jump: boolean;
  action: boolean;
}

// Collision result
export interface CollisionResult {
  collided: boolean;
  side?: 'top' | 'bottom' | 'left' | 'right';
  element?: GameElement;
  penetration?: { x: number; y: number };
}

// Level validation result
export interface LevelValidation {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

// Level statistics
export interface LevelStats {
  totalElements: number;
  coinCount: number;
  obstacleCount: number;
  goalCount: number;
  estimatedDifficulty: 'easy' | 'medium' | 'hard';
  estimatedPlayTime: number; // in seconds
}

// Editor tool types
export type EditorTool = 'select' | 'place' | 'delete' | 'move';

// Editor state
export interface EditorState {
  selectedTool: EditorTool;
  selectedElementType: ElementType;
  gridSize: number;
  snapToGrid: boolean;
  showGrid: boolean;
  zoom: number;
  camera: { x: number; y: number };
}

// Network level sharing
export interface SharedLevel extends GameLevel {
  shareId: string;
  shareUrl: string;
  isPublic: boolean;
  downloads: number;
  likes: number;
}

// Game configuration
export interface GameConfig {
  physics: {
    gravity: number;
    jumpStrength: number;
    moveSpeed: number;
    friction: number;
  };
  graphics: {
    showFPS: boolean;
    showDebug: boolean;
    particleEffects: boolean;
  };
  audio: {
    masterVolume: number;
    musicVolume: number;
    sfxVolume: number;
    muted: boolean;
  };
}

// Achievement system
export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress: number;
  maxProgress: number;
}

// Save game data
export interface SaveData {
  playerStats: {
    totalScore: number;
    totalCoins: number;
    levelsCompleted: number;
    totalPlayTime: number;
  };
  achievements: Achievement[];
  unlockedLevels: string[];
  settings: GameConfig;
  createdLevels: string[];
}
