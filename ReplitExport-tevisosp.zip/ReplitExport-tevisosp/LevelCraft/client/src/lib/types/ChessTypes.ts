// Chess piece types
export type PieceType = 'king' | 'queen' | 'rook' | 'bishop' | 'knight' | 'pawn';
export type PieceColor = 'white' | 'black';

export interface Piece {
  type: PieceType;
  color: PieceColor;
  hasMoved?: boolean; // For castling and en passant
  isFirstMove?: boolean; // For pawn double move
  // Enhanced properties for modified chess
  age: number; // How many turns the piece has been idle
  movesCount: number; // How many times the piece has moved
  capturesCount: number; // How many pieces this piece has captured
  value: number; // Current value of the piece
  isRecruited?: boolean; // Was this piece recruited from opponent
  recruitmentCost?: number; // Cost to recruit this piece
  id: string; // Unique identifier for tracking across games
}

export interface Position {
  row: number;
  col: number;
}

export interface Move {
  from: string; // e.g., "e2"
  to: string;   // e.g., "e4"
  piece: Piece;
  player: PieceColor;
  capturedPiece?: Piece;
  recruitedPiece?: Piece; // Piece that was recruited instead of captured
  isEnPassant?: boolean;
  isCastling?: boolean;
  isRecruitment?: boolean; // Was this a recruitment move
  promotion?: PieceType; // For pawn promotion
  timestamp?: number;
  capitalUsed?: number; // Capital spent on recruitment
}

export interface ChessGameState {
  board: (Piece | null)[][]; // 8x8 board
  currentPlayer: PieceColor;
  moveHistory: Move[];
  isCheck: boolean;
  isCheckmate: boolean;
  isStalemate: boolean;
  canCastle: {
    white: { kingside: boolean; queenside: boolean };
    black: { kingside: boolean; queenside: boolean };
  };
  enPassantTarget?: string; // e.g., "e3"
  halfMoveClock: number; // For 50-move rule
  fullMoveNumber: number;
  // Enhanced game state
  gameNumber: number; // Current game in the campaign
  capital: { white: number; black: number }; // Capital for recruitment
  gameEndOffered?: PieceColor; // Which player offered to end the game
}

export interface GameRules {
  // Modified chess rules
  enableEnPassant: boolean;
  enableCastling: boolean;
  enablePromotion: boolean;
  pieceValues: Record<PieceType, number>;
  specialMoves: {
    knightCanJumpOverPieces: boolean;
    bishopCanMoveOneSquare: boolean;
    rookCanMoveOneSquare: boolean;
    queenCanTeleport: boolean; // Custom rule
    kingCanMoveTwo: boolean; // Custom rule
    pawnCanMoveThree: boolean; // Custom rule
  };
  timeControl: {
    enabled: boolean;
    initialTime: number; // in seconds
    increment: number; // per move
  };
  boardModifications: {
    size: { rows: number; cols: number };
    obstacles: Position[]; // Blocked squares
    portals: { from: Position; to: Position }[]; // Teleport squares
  };
}

export interface PlayerInfo {
  name: string;
  color: PieceColor;
  timeRemaining: number;
  capturedPieces: Piece[];
  score: number;
  capital: number; // Capital for recruitment
  veteranPieces: Piece[]; // Pieces carried over from previous games
}

// Enhanced interfaces for modified chess rules
export interface PieceRank {
  name: string;
  types: PieceType[];
  baseValue: number;
  rank: number; // 1=пешки, 2=слоны/кони, 3=ладьи, 4=ферзь
}

export interface RecruitmentAction {
  targetPiece: Piece;
  cost: number;
  position: Position;
  isAvailable: boolean;
  description: string;
}

export interface GameCampaign {
  games: ChessGameState[];
  currentGameIndex: number;
  totalCapital: { white: number; black: number };
  veteranPieces: { white: Piece[]; black: Piece[] };
  campaignHistory: GameResult[];
}

export interface ChessStore {
  gameState: ChessGameState;
  currentPlayer: PieceColor;
  selectedSquare: string | null;
  validMoves: string[];
  recruitmentOptions: RecruitmentAction[];
  gameHistory: Move[];
  capturedPieces: { white: Piece[]; black: Piece[] };
  isGameOver: boolean;
  winner: PieceColor | null;
  players: { white: PlayerInfo; black: PlayerInfo };
  gameRules: GameRules;
  campaign: GameCampaign;
  showRecruitmentUI: boolean;
  
  // Actions
  initializeGame: () => void;
  initializeCampaign: () => void;
  makeMove: (move: Move) => void;
  selectSquare: (square: string) => void;
  resetGame: () => void;
  undoMove: () => void;
  setGameRules: (rules: Partial<GameRules>) => void;
  calculateValidMoves: (square: string) => string[];
  
  // Enhanced actions for modified chess
  recruitPiece: (action: RecruitmentAction) => void;
  offerGameEnd: () => void;
  acceptGameEnd: () => void;
  startNextGame: () => void;
  sellPieceForCapital: (piece: Piece) => void;
  addVeteranPiece: (piece: Piece) => void;
  calculateRecruitmentCost: (piece: Piece) => number;
  agePieces: () => void;
  updatePieceValues: () => void;
  checkCanCapture: (attacker: Piece, target: Piece) => boolean;
}

// Special move types for modified chess
export interface SpecialMove {
  type: 'teleport' | 'jump' | 'multi_capture' | 'power_move';
  from: string;
  to: string;
  piece: Piece;
  description: string;
  cost?: number; // For moves that cost points
}

// Tournament/scoring system
export interface GameResult {
  winner: PieceColor | 'draw';
  reason: 'checkmate' | 'stalemate' | 'resignation' | 'time' | 'draw_by_agreement';
  moves: number;
  duration: number; // in seconds
  finalPosition: string; // FEN notation
}

// AI difficulty levels
export type AILevel = 'beginner' | 'intermediate' | 'advanced' | 'expert';

export interface AIConfig {
  level: AILevel;
  thinkingTime: number; // in seconds
  randomness: number; // 0-1, for unpredictable play
  specialMovePreference: number; // 0-1, how often to use special moves
}

// Game modes
export type GameMode = 'classic' | 'modified' | 'puzzle' | 'tournament' | 'ai_vs_human' | 'human_vs_human';

export interface GameConfig {
  mode: GameMode;
  rules: GameRules;
  timeControl: {
    enabled: boolean;
    timePerPlayer: number;
    increment: number;
  };
  aiConfig?: AIConfig;
  players: {
    white: { name: string; isHuman: boolean };
    black: { name: string; isHuman: boolean };
  };
}

// Puzzle types for training mode
export interface ChessPuzzle {
  id: string;
  name: string;
  description: string;
  startingPosition: string; // FEN notation
  solution: Move[];
  difficulty: 'easy' | 'medium' | 'hard';
  theme: string; // e.g., "tactics", "endgame", "opening"
  rating: number;
}

// Analysis features
export interface PositionAnalysis {
  evaluation: number; // Positive favors white, negative favors black
  bestMove: Move | null;
  principalVariation: Move[];
  threats: {
    piece: string;
    target: string;
    severity: 'low' | 'medium' | 'high';
  }[];
  suggestions: string[];
}