import { useState, useCallback } from 'react';
import { useLevelStore } from '../../lib/stores/useLevelStore';
import { GameLevel, GameElement } from '../../lib/types/GameTypes';
import ElementPalette from './ElementPalette';
import GridCanvas from './GridCanvas';

interface LevelEditorProps {
  onBack: () => void;
  onPlayTest: (levelId: string) => void;
}

const LevelEditor = ({ onBack, onPlayTest }: LevelEditorProps) => {
  const { currentLevel, setCurrentLevel, saveLevel } = useLevelStore();
  const [selectedElement, setSelectedElement] = useState<string>('platform');
  const [isDrawing, setIsDrawing] = useState(false);
  const [levelName, setLevelName] = useState(currentLevel?.name || 'New Level');
  
  // Initialize empty level if none exists
  const level: GameLevel = currentLevel || {
    id: 'temp',
    name: 'New Level',
    width: 1200,
    height: 800,
    elements: [],
    playerStart: { x: 50, y: 100 }
  };

  const handleAddElement = useCallback((x: number, y: number) => {
    const gridSize = 40;
    const snappedX = Math.round(x / gridSize) * gridSize;
    const snappedY = Math.round(y / gridSize) * gridSize;

    const elementSizes: Record<string, {width: number, height: number, color: string}> = {
      platform: { width: 80, height: 40, color: '#8B4513' },
      coin: { width: 30, height: 30, color: '#FFD700' },
      obstacle: { width: 40, height: 40, color: '#FF4444' },
      goal: { width: 60, height: 120, color: '#00FF00' },
      enemy: { width: 40, height: 40, color: '#FF0000' }
    };

    const size = elementSizes[selectedElement] || elementSizes.platform;

    const newElement: GameElement = {
      type: selectedElement as GameElement['type'],
      x: snappedX,
      y: snappedY,
      width: size.width,
      height: size.height,
      color: size.color
    };

    const updatedLevel = {
      ...level,
      elements: [...level.elements, newElement]
    };

    setCurrentLevel(updatedLevel);
  }, [selectedElement, level, setCurrentLevel]);

  const handleRemoveElement = useCallback((index: number) => {
    const updatedLevel = {
      ...level,
      elements: level.elements.filter((_, i) => i !== index)
    };
    setCurrentLevel(updatedLevel);
  }, [level, setCurrentLevel]);

  const handleMovePlayerStart = useCallback((x: number, y: number) => {
    const gridSize = 40;
    const snappedX = Math.round(x / gridSize) * gridSize;
    const snappedY = Math.round(y / gridSize) * gridSize;

    const updatedLevel = {
      ...level,
      playerStart: { x: snappedX, y: snappedY }
    };
    setCurrentLevel(updatedLevel);
  }, [level, setCurrentLevel]);

  const handleSave = async () => {
    const levelToSave = {
      ...level,
      name: levelName,
      id: level.id === 'temp' ? Date.now().toString() : level.id
    };
    
    await saveLevel(levelToSave);
    alert('Level saved successfully!');
  };

  const handlePlayTest = () => {
    const testLevel = {
      ...level,
      name: levelName,
      id: 'playtest'
    };
    setCurrentLevel(testLevel);
    onPlayTest('playtest');
  };

  const handleClear = () => {
    if (confirm('Are you sure you want to clear the level?')) {
      const clearedLevel = {
        ...level,
        elements: [],
        playerStart: { x: 50, y: 100 }
      };
      setCurrentLevel(clearedLevel);
    }
  };

  const handleExport = () => {
    const dataStr = JSON.stringify(level, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `${levelName.replace(/\s+/g, '_')}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedLevel = JSON.parse(e.target?.result as string);
        setCurrentLevel(importedLevel);
        setLevelName(importedLevel.name || 'Imported Level');
      } catch (error) {
        alert('Error importing level: Invalid file format');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="h-full flex flex-col bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="bg-gray-500 text-white px-3 py-1 rounded hover:bg-gray-600"
          >
            ← Back
          </button>
          <input
            type="text"
            value={levelName}
            onChange={(e) => setLevelName(e.target.value)}
            className="border border-gray-300 px-3 py-1 rounded"
            placeholder="Level name"
          />
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={handleClear}
            className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
          >
            Clear
          </button>
          <input
            type="file"
            accept=".json"
            onChange={handleImport}
            className="hidden"
            id="import-file"
          />
          <label
            htmlFor="import-file"
            className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 cursor-pointer"
          >
            Import
          </label>
          <button
            onClick={handleExport}
            className="bg-purple-500 text-white px-3 py-1 rounded hover:bg-purple-600"
          >
            Export
          </button>
          <button
            onClick={handleSave}
            className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600"
          >
            Save
          </button>
          <button
            onClick={handlePlayTest}
            className="bg-orange-500 text-white px-3 py-1 rounded hover:bg-orange-600"
          >
            Test Play
          </button>
        </div>
      </div>

      {/* Main editor area */}
      <div className="flex-1 flex">
        {/* Element palette */}
        <div className="w-64 bg-white border-r p-4">
          <h3 className="font-bold mb-4">Elements</h3>
          <ElementPalette
            selectedElement={selectedElement}
            onSelectElement={setSelectedElement}
          />
          
          <div className="mt-6">
            <h4 className="font-semibold mb-2">Instructions</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Click to place elements</li>
              <li>• Click elements to remove them</li>
              <li>• Drag the blue square to move player start</li>
              <li>• Elements snap to grid</li>
            </ul>
          </div>

          <div className="mt-6">
            <h4 className="font-semibold mb-2">Stats</h4>
            <div className="text-sm text-gray-600">
              <p>Elements: {level.elements.length}</p>
              <p>Coins: {level.elements.filter(e => e.type === 'coin').length}</p>
              <p>Goals: {level.elements.filter(e => e.type === 'goal').length}</p>
            </div>
          </div>
        </div>

        {/* Canvas area */}
        <div className="flex-1 overflow-auto">
          <GridCanvas
            level={level}
            selectedElement={selectedElement}
            onAddElement={handleAddElement}
            onRemoveElement={handleRemoveElement}
            onMovePlayerStart={handleMovePlayerStart}
          />
        </div>
      </div>
    </div>
  );
};

export default LevelEditor;
