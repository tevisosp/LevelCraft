import React, { useRef, useEffect, useState } from 'react';
import { GameLevel, GameElement } from '../../lib/types/GameTypes';
import { renderGameObject } from '../game/GameObject';

interface GridCanvasProps {
  level: GameLevel;
  selectedElement: string;
  onAddElement: (x: number, y: number) => void;
  onRemoveElement: (index: number) => void;
  onMovePlayerStart: (x: number, y: number) => void;
}

const GridCanvas = ({ 
  level, 
  selectedElement, 
  onAddElement, 
  onRemoveElement, 
  onMovePlayerStart 
}: GridCanvasProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDraggingPlayer, setIsDraggingPlayer] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const gridSize = 40;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = level.width;
    canvas.height = level.height;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw grid
    ctx.strokeStyle = '#E0E0E0';
    ctx.lineWidth = 1;

    // Vertical lines
    for (let x = 0; x <= level.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, level.height);
      ctx.stroke();
    }

    // Horizontal lines
    for (let y = 0; y <= level.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(level.width, y);
      ctx.stroke();
    }

    // Draw elements
    level.elements.forEach((element, index) => {
      renderGameObject(element, ctx);
      
      // Add element index for debugging
      ctx.fillStyle = '#000000';
      ctx.font = '12px Arial';
      ctx.fillText(index.toString(), element.x + 5, element.y + 15);
    });

    // Draw player start position
    const playerStart = level.playerStart;
    ctx.fillStyle = '#4A90E2';
    ctx.fillRect(playerStart.x, playerStart.y, 30, 40);
    
    // Add player label
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '10px Arial';
    ctx.fillText('P', playerStart.x + 12, playerStart.y + 25);

    // Draw preview of element being placed
    if (mousePos.x >= 0 && mousePos.y >= 0 && !isDraggingPlayer) {
      const snappedX = Math.round(mousePos.x / gridSize) * gridSize;
      const snappedY = Math.round(mousePos.y / gridSize) * gridSize;

      const elementSizes: Record<string, {width: number, height: number, color: string}> = {
        platform: { width: 80, height: 40, color: '#8B4513' },
        coin: { width: 30, height: 30, color: '#FFD700' },
        obstacle: { width: 40, height: 40, color: '#FF4444' },
        goal: { width: 60, height: 120, color: '#00FF00' },
        enemy: { width: 40, height: 40, color: '#FF0000' }
      };

      const size = elementSizes[selectedElement];
      if (size) {
        ctx.save();
        ctx.globalAlpha = 0.5;
        
        const previewElement: GameElement = {
          type: selectedElement as GameElement['type'],
          x: snappedX,
          y: snappedY,
          width: size.width,
          height: size.height,
          color: size.color
        };

        renderGameObject(previewElement, ctx);
        ctx.restore();
      }
    }

  }, [level, selectedElement, mousePos, isDraggingPlayer]);

  const getMousePos = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const pos = getMousePos(e);
    setMousePos(pos);

    if (isDraggingPlayer) {
      onMovePlayerStart(pos.x, pos.y);
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const pos = getMousePos(e);

    // Check if clicking on player start position
    const playerStart = level.playerStart;
    if (
      pos.x >= playerStart.x &&
      pos.x <= playerStart.x + 30 &&
      pos.y >= playerStart.y &&
      pos.y <= playerStart.y + 40
    ) {
      setIsDraggingPlayer(true);
      return;
    }

    // Check if clicking on existing element
    for (let i = level.elements.length - 1; i >= 0; i--) {
      const element = level.elements[i];
      if (
        pos.x >= element.x &&
        pos.x <= element.x + element.width &&
        pos.y >= element.y &&
        pos.y <= element.y + element.height
      ) {
        onRemoveElement(i);
        return;
      }
    }

    // Add new element
    onAddElement(pos.x, pos.y);
  };

  const handleMouseUp = () => {
    setIsDraggingPlayer(false);
  };

  const handleMouseLeave = () => {
    setMousePos({ x: -1, y: -1 });
    setIsDraggingPlayer(false);
  };

  return (
    <div className="p-4 bg-gray-50">
      <div className="bg-white border border-gray-300 inline-block">
        <canvas
          ref={canvasRef}
          onMouseMove={handleMouseMove}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseLeave}
          className="cursor-crosshair"
          style={{ maxWidth: '100%', height: 'auto' }}
        />
      </div>
      
      <div className="mt-4 text-sm text-gray-600">
        <p>Canvas size: {level.width} x {level.height} pixels</p>
        <p>Grid size: {gridSize} pixels</p>
        <p>Selected tool: {selectedElement}</p>
      </div>
    </div>
  );
};

export default GridCanvas;
