import React from 'react';

interface ElementPaletteProps {
  selectedElement: string;
  onSelectElement: (element: string) => void;
}

const ElementPalette = ({ selectedElement, onSelectElement }: ElementPaletteProps) => {
  const elements = [
    {
      type: 'platform',
      name: 'Platform',
      color: '#8B4513',
      icon: '🟫',
      description: 'Solid platform for jumping'
    },
    {
      type: 'coin',
      name: 'Coin',
      color: '#FFD700',
      icon: '🪙',
      description: 'Collectible coin'
    },
    {
      type: 'obstacle',
      name: 'Spikes',
      color: '#FF4444',
      icon: '⚡',
      description: 'Deadly spikes'
    },
    {
      type: 'goal',
      name: 'Goal',
      color: '#00FF00',
      icon: '🏁',
      description: 'Level finish line'
    },
    {
      type: 'enemy',
      name: 'Enemy',
      color: '#FF0000',
      icon: '👾',
      description: 'Moving enemy'
    }
  ];

  return (
    <div className="space-y-2">
      {elements.map((element) => (
        <div
          key={element.type}
          onClick={() => onSelectElement(element.type)}
          className={`p-3 border rounded cursor-pointer transition-all ${
            selectedElement === element.type
              ? 'border-blue-500 bg-blue-50'
              : 'border-gray-300 hover:border-gray-400 hover:bg-gray-50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div 
              className="w-8 h-8 flex items-center justify-center rounded text-white font-bold"
              style={{ backgroundColor: element.color }}
            >
              {element.icon}
            </div>
            <div>
              <div className="font-medium">{element.name}</div>
              <div className="text-xs text-gray-500">{element.description}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ElementPalette;
