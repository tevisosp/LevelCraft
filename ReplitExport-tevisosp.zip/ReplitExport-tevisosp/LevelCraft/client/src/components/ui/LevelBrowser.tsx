import React, { useState, useEffect } from 'react';
import { useLevelStore } from '../../lib/stores/useLevelStore';
import { GameLevel } from '../../lib/types/GameTypes';

interface LevelBrowserProps {
  onBack: () => void;
  onPlayLevel: (levelId: string) => void;
}

const LevelBrowser = ({ onBack, onPlayLevel }: LevelBrowserProps) => {
  const { loadLevelsList, saveLevelRating } = useLevelStore();
  const [levels, setLevels] = useState<GameLevel[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLevel, setSelectedLevel] = useState<GameLevel | null>(null);

  useEffect(() => {
    // Load levels from localStorage and server
    const loadLevels = async () => {
      setLoading(true);
      try {
        // Load from localStorage first
        const savedLevels: GameLevel[] = [];
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key?.startsWith('level_')) {
            try {
              const level = JSON.parse(localStorage.getItem(key) || '');
              if (level && level.id) {
                savedLevels.push({
                  ...level,
                  author: 'Local',
                  plays: Math.floor(Math.random() * 50),
                  rating: parseFloat((Math.random() * 2 + 3).toFixed(1)), // 3-5 rating
                  created: new Date().toISOString()
                });
              }
            } catch (e) {
              console.warn('Failed to parse level from localStorage:', key);
            }
          }
        }

        // Add some sample community levels
        const sampleLevels: GameLevel[] = [
          {
            id: 'sample1',
            name: 'Sky High Adventure',
            width: 1200,
            height: 800,
            elements: [
              { type: 'platform', x: 0, y: 750, width: 200, height: 50, color: '#8B4513' },
              { type: 'platform', x: 300, y: 600, width: 150, height: 30, color: '#8B4513' },
              { type: 'platform', x: 500, y: 450, width: 150, height: 30, color: '#8B4513' },
              { type: 'platform', x: 700, y: 300, width: 150, height: 30, color: '#8B4513' },
              { type: 'coin', x: 350, y: 550, width: 30, height: 30, color: '#FFD700' },
              { type: 'coin', x: 550, y: 400, width: 30, height: 30, color: '#FFD700' },
              { type: 'coin', x: 750, y: 250, width: 30, height: 30, color: '#FFD700' },
              { type: 'goal', x: 1100, y: 200, width: 60, height: 120, color: '#00FF00' },
            ],
            playerStart: { x: 50, y: 700 },
            author: 'GameMaster',
            plays: 234,
            rating: 4.8,
            created: '2024-01-15'
          },
          {
            id: 'sample2',
            name: 'Danger Zone',
            width: 1000,
            height: 600,
            elements: [
              { type: 'platform', x: 0, y: 550, width: 150, height: 50, color: '#8B4513' },
              { type: 'platform', x: 200, y: 500, width: 100, height: 30, color: '#8B4513' },
              { type: 'platform', x: 350, y: 450, width: 100, height: 30, color: '#8B4513' },
              { type: 'obstacle', x: 250, y: 470, width: 40, height: 30, color: '#FF4444' },
              { type: 'obstacle', x: 400, y: 420, width: 40, height: 30, color: '#FF4444' },
              { type: 'coin', x: 220, y: 460, width: 30, height: 30, color: '#FFD700' },
              { type: 'coin', x: 370, y: 410, width: 30, height: 30, color: '#FFD700' },
              { type: 'goal', x: 900, y: 350, width: 60, height: 120, color: '#00FF00' },
            ],
            playerStart: { x: 50, y: 500 },
            author: 'ChallengeSeeker',
            plays: 127,
            rating: 4.2,
            created: '2024-01-20'
          },
          {
            id: 'sample3',
            name: 'Coin Collection',
            width: 1400,
            height: 700,
            elements: [
              { type: 'platform', x: 0, y: 650, width: 200, height: 50, color: '#8B4513' },
              { type: 'platform', x: 250, y: 550, width: 100, height: 30, color: '#8B4513' },
              { type: 'platform', x: 400, y: 450, width: 100, height: 30, color: '#8B4513' },
              { type: 'platform', x: 550, y: 350, width: 100, height: 30, color: '#8B4513' },
              { type: 'platform', x: 700, y: 450, width: 100, height: 30, color: '#8B4513' },
              { type: 'platform', x: 850, y: 550, width: 100, height: 30, color: '#8B4513' },
              { type: 'platform', x: 1000, y: 450, width: 200, height: 50, color: '#8B4513' },
              // Lots of coins
              { type: 'coin', x: 270, y: 510, width: 30, height: 30, color: '#FFD700' },
              { type: 'coin', x: 420, y: 410, width: 30, height: 30, color: '#FFD700' },
              { type: 'coin', x: 570, y: 310, width: 30, height: 30, color: '#FFD700' },
              { type: 'coin', x: 720, y: 410, width: 30, height: 30, color: '#FFD700' },
              { type: 'coin', x: 870, y: 510, width: 30, height: 30, color: '#FFD700' },
              { type: 'coin', x: 1050, y: 400, width: 30, height: 30, color: '#FFD700' },
              { type: 'goal', x: 1300, y: 350, width: 60, height: 120, color: '#00FF00' },
            ],
            playerStart: { x: 50, y: 600 },
            author: 'CoinHunter',
            plays: 89,
            rating: 4.5,
            created: '2024-01-22'
          }
        ];

        const allLevels = [...savedLevels, ...sampleLevels];
        setLevels(allLevels);
      } catch (error) {
        console.error('Failed to load levels:', error);
      } finally {
        setLoading(false);
      }
    };

    loadLevels();
  }, []);

  const handlePlayLevel = (level: GameLevel) => {
    // Save to current level store and play
    useLevelStore.getState().setCurrentLevel(level);
    onPlayLevel(level.id);
  };

  const handleRateLevel = (levelId: string, rating: number) => {
    setLevels(levels.map(level => {
      if (level.id === levelId) {
        const newRating = ((level.rating || 0) + rating) / 2; // Simple average
        return { ...level, rating: Math.round(newRating * 10) / 10 };
      }
      return level;
    }));
  };

  const handleLevelDetails = (level: GameLevel) => {
    setSelectedLevel(level);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-xl">Loading levels...</div>
      </div>
    );
  }

  return (
    <div className="h-full bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="bg-gray-500 text-white px-3 py-1 rounded hover:bg-gray-600"
          >
            ← Back
          </button>
          <h1 className="text-2xl font-bold">Community Levels</h1>
        </div>
        <div className="text-sm text-gray-600">
          {levels.length} levels available
        </div>
      </div>

      {/* Levels grid */}
      <div className="p-6">
        {levels.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-500 text-lg mb-4">No levels found</div>
            <p className="text-gray-400">Create some levels in the editor to see them here!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {levels.map((level) => (
              <div key={level.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                {/* Level preview */}
                <div className="h-32 bg-gradient-to-br from-blue-200 to-green-200 relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-4xl">🎮</div>
                  </div>
                  <div className="absolute bottom-2 right-2 text-xs bg-black bg-opacity-50 text-white px-2 py-1 rounded">
                    {level.elements.length} elements
                  </div>
                </div>

                {/* Level info */}
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-2 truncate">{level.name}</h3>
                  
                  <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                    <span>by {level.author || 'Anonymous'}</span>
                    <span>{level.plays || 0} plays</span>
                  </div>

                  {/* Rating */}
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => handleRateLevel(level.id, star)}
                          className="text-yellow-400 hover:text-yellow-500"
                        >
                          {star <= (level.rating || 0) ? '⭐' : '☆'}
                        </button>
                      ))}
                    </div>
                    <span className="text-sm text-gray-500">
                      {level.rating?.toFixed(1) || 'No rating'}
                    </span>
                  </div>

                  {/* Level stats */}
                  <div className="grid grid-cols-3 gap-2 text-xs text-gray-500 mb-4">
                    <div>
                      🪙 {level.elements.filter(e => e.type === 'coin').length}
                    </div>
                    <div>
                      🏁 {level.elements.filter(e => e.type === 'goal').length}
                    </div>
                    <div>
                      ⚡ {level.elements.filter(e => e.type === 'obstacle').length}
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => handlePlayLevel(level)}
                      className="flex-1 bg-green-500 text-white py-2 rounded hover:bg-green-600 transition-colors"
                    >
                      Play
                    </button>
                    <button
                      onClick={() => handleLevelDetails(level)}
                      className="bg-blue-500 text-white px-3 py-2 rounded hover:bg-blue-600 transition-colors"
                    >
                      Info
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Level details modal */}
      {selectedLevel && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h2 className="text-2xl font-bold mb-4">{selectedLevel.name}</h2>
            
            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span className="font-medium">Author:</span>
                <span>{selectedLevel.author || 'Anonymous'}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Size:</span>
                <span>{selectedLevel.width} × {selectedLevel.height}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Elements:</span>
                <span>{selectedLevel.elements.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Coins:</span>
                <span>{selectedLevel.elements.filter(e => e.type === 'coin').length}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Plays:</span>
                <span>{selectedLevel.plays || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Rating:</span>
                <span>{selectedLevel.rating?.toFixed(1) || 'No rating'} ⭐</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => handlePlayLevel(selectedLevel)}
                className="flex-1 bg-green-500 text-white py-2 rounded hover:bg-green-600"
              >
                Play Level
              </button>
              <button
                onClick={() => setSelectedLevel(null)}
                className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LevelBrowser;
