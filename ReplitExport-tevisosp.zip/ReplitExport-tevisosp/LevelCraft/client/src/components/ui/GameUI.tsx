import React from 'react';
import { usePlayerStore } from '../../lib/stores/usePlayerStore';
import { useGame } from '../../lib/stores/useGame';

const GameUI = () => {
  const { health, coins, score, lives } = usePlayerStore();
  const { phase } = useGame();

  if (phase !== 'playing') return null;

  return (
    <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-10">
      <div className="bg-black bg-opacity-60 text-white px-6 py-3 rounded-lg flex items-center gap-6">
        {/* Score */}
        <div className="flex items-center gap-2">
          <span className="text-yellow-400">⭐</span>
          <span className="font-mono">{score.toString().padStart(6, '0')}</span>
        </div>

        {/* Coins */}
        <div className="flex items-center gap-2">
          <span className="text-yellow-300">🪙</span>
          <span className="font-mono">{coins.toString().padStart(2, '0')}</span>
        </div>

        {/* Lives */}
        <div className="flex items-center gap-2">
          <span className="text-red-400">❤️</span>
          <span className="font-mono">{lives}</span>
        </div>

        {/* Health bar */}
        <div className="flex items-center gap-2">
          <span className="text-green-400">HP</span>
          <div className="w-20 h-2 bg-red-600 rounded-full overflow-hidden">
            <div 
              className="h-full bg-green-400 transition-all duration-300"
              style={{ width: `${(health / 100) * 100}%` }}
            />
          </div>
          <span className="text-xs">{health}/100</span>
        </div>
      </div>

      {/* Controls hint */}
      <div className="bg-black bg-opacity-40 text-white text-xs px-3 py-1 rounded mt-2 text-center">
        WASD/Arrows to move • Space to jump • ESC to pause
      </div>
    </div>
  );
};

export default GameUI;
