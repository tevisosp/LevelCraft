import React, { useState } from 'react';

interface MenuProps {
  onModeChange: (mode: 'play' | 'editor' | 'browser' | 'chess') => void;
}

const Menu = ({ onModeChange }: MenuProps) => {
  const [showInstructions, setShowInstructions] = useState(false);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-blue-400 to-green-400">
      <div className="text-center">
        {/* Title */}
        <div className="mb-12">
          <h1 className="text-6xl font-bold text-white mb-4 drop-shadow-lg">
            Level Craft
          </h1>
          <p className="text-xl text-white drop-shadow">
            Create, Share, and Play Custom Levels
          </p>
        </div>

        {/* Menu buttons */}
        <div className="space-y-4 mb-8">
          <button
            onClick={() => onModeChange('play')}
            className="block w-64 mx-auto bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-8 rounded-lg text-xl transition-colors duration-200 shadow-lg"
          >
            🎮 Play Default Level
          </button>

          <button
            onClick={() => onModeChange('editor')}
            className="block w-64 mx-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-4 px-8 rounded-lg text-xl transition-colors duration-200 shadow-lg"
          >
            🛠️ Level Editor
          </button>

          <button
            onClick={() => onModeChange('browser')}
            className="block w-64 mx-auto bg-purple-500 hover:bg-purple-600 text-white font-bold py-4 px-8 rounded-lg text-xl transition-colors duration-200 shadow-lg"
          >
            🌐 Browse Levels
          </button>

          <button
            onClick={() => onModeChange('chess')}
            className="block w-64 mx-auto bg-amber-600 hover:bg-amber-700 text-white font-bold py-4 px-8 rounded-lg text-xl transition-colors duration-200 shadow-lg"
          >
            ♔ Chess Game
          </button>

          <button
            onClick={() => setShowInstructions(!showInstructions)}
            className="block w-64 mx-auto bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-4 px-8 rounded-lg text-xl transition-colors duration-200 shadow-lg"
          >
            ❓ How to Play
          </button>
        </div>

        {/* Instructions panel */}
        {showInstructions && (
          <div className="bg-white bg-opacity-90 rounded-lg p-6 max-w-2xl mx-auto text-left">
            <h3 className="text-2xl font-bold mb-4 text-gray-800">How to Play</h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold mb-2 text-gray-700">🎮 Playing</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Use WASD or Arrow keys to move</li>
                  <li>• Space bar or W to jump</li>
                  <li>• Collect all coins 🪙</li>
                  <li>• Avoid spikes and enemies</li>
                  <li>• Reach the green flag to win 🏁</li>
                </ul>
              </div>

              <div>
                <h4 className="text-lg font-semibold mb-2 text-gray-700">🛠️ Level Editor</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Click elements from the palette</li>
                  <li>• Click on canvas to place them</li>
                  <li>• Click existing elements to remove</li>
                  <li>• Drag blue square to move player start</li>
                  <li>• Test your level before saving</li>
                </ul>
              </div>
            </div>

            <div className="mt-6">
              <h4 className="text-lg font-semibold mb-2 text-gray-700">📱 Mobile Controls</h4>
              <p className="text-sm text-gray-600">
                Tap left/right sides of screen to move, center to jump
              </p>
            </div>

            <button
              onClick={() => setShowInstructions(false)}
              className="mt-4 bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded"
            >
              Close
            </button>
          </div>
        )}

        {/* Footer */}
        <div className="mt-12 text-white text-sm">
          <p>Made with ❤️ for casual gamers</p>
        </div>
      </div>
    </div>
  );
};

export default Menu;
