import React, { useState, useCallback, useEffect } from 'react';
import { ChessBoard } from './ChessBoard';
import { RecruitmentPanel } from './RecruitmentPanel';
import { GameInfoPanel } from './GameInfoPanel';
import { ChessGameState, Piece, Position, Move } from '../../lib/types/ChessTypes';
import { EnhancedChessEngine } from '../../lib/game/EnhancedChessEngine';
import { useChessStore } from '../../lib/stores/useChessStore';

interface ChessGameProps {
  onBack: () => void;
}

export const ChessGame: React.FC<ChessGameProps> = ({ onBack }) => {
  const {
    gameState,
    currentPlayer,
    selectedSquare,
    validMoves,
    recruitmentOptions,
    gameHistory,
    capturedPieces,
    isGameOver,
    winner,
    showRecruitmentUI,
    initializeGame,
    makeMove,
    selectSquare,
    resetGame,
    undoMove,
    recruitPiece,
    offerGameEnd,
    startNextGame
  } = useChessStore();

  const [engine] = useState(() => new EnhancedChessEngine());
  const [showRecruitment, setShowRecruitment] = useState(false);

  useEffect(() => {
    initializeGame();
  }, [initializeGame]);

  const handleSquareClick = useCallback((position: Position) => {
    const square = `${String.fromCharCode(97 + position.col)}${8 - position.row}`;
    
    if (selectedSquare) {
      // Try to make a move
      const fromPos = engine.squareToPosition(selectedSquare);
      const piece = gameState.board[fromPos.row][fromPos.col];
      
      if (!piece) return;
      
      const move: Move = {
        from: selectedSquare,
        to: square,
        piece: piece,
        player: currentPlayer
      };
      
      if (engine.isValidEnhancedMove(gameState, move)) {
        makeMove(move);
      } else {
        // Select new square
        selectSquare(square);
      }
    } else {
      selectSquare(square);
    }
  }, [selectedSquare, gameState, currentPlayer, makeMove, selectSquare, engine]);

  const handleNewGame = () => {
    resetGame();
    initializeGame();
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-amber-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={onBack}
            className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors"
          >
            ← Назад к меню
          </button>
          <h1 className="text-3xl font-bold text-gray-800">Модифицированные шахматы</h1>
          <div className="w-24"></div> {/* Spacer */}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Enhanced Game Info Panel */}
          <div className="lg:col-span-1">
            <GameInfoPanel
              gameState={gameState}
              currentPlayer={currentPlayer}
              capturedPieces={capturedPieces}
              onOfferGameEnd={offerGameEnd}
              onShowRecruitment={() => setShowRecruitment(true)}
              onStartNextGame={startNextGame}
              isGameOver={isGameOver}
            />
          </div>

          {/* Chess board */}
          <div className="lg:col-span-3 flex justify-center">
            <ChessBoard
              gameState={gameState}
              selectedSquare={selectedSquare}
              validMoves={validMoves}
              onSquareClick={handleSquareClick}
              currentPlayer={currentPlayer}
            />
          </div>
        </div>

        {/* Recruitment Panel */}
        {showRecruitment && (
          <RecruitmentPanel
            recruitmentOptions={recruitmentOptions}
            currentPlayer={currentPlayer}
            playerCapital={gameState.capital[currentPlayer]}
            onRecruitPiece={(action) => {
              recruitPiece(action);
              setShowRecruitment(false);
            }}
            onClose={() => setShowRecruitment(false)}
          />
        )}

        {/* Game over modal */}
        {isGameOver && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4">
              <h2 className="text-2xl font-bold text-center mb-4">
                Игра окончена!
              </h2>
              <div className="text-xl text-center mb-6">
                {winner ? (
                  <>Победили <span className="font-bold">{winner === 'white' ? 'белые' : 'черные'}</span>!</>
                ) : (
                  'Ничья!'
                )}
              </div>
              <div className="flex gap-4">
                <button
                  onClick={handleNewGame}
                  className="flex-1 bg-green-600 text-white py-2 rounded hover:bg-green-700 transition-colors"
                >
                  Новая игра
                </button>
                <button
                  onClick={onBack}
                  className="flex-1 bg-gray-600 text-white py-2 rounded hover:bg-gray-700 transition-colors"
                >
                  В меню
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Helper function to get piece symbol
function getPieceSymbol(piece: Piece | null): string {
  if (!piece) return '';
  
  const symbols = {
    'white': {
      'king': '♔',
      'queen': '♕',
      'rook': '♖',
      'bishop': '♗',
      'knight': '♘',
      'pawn': '♙'
    },
    'black': {
      'king': '♚',
      'queen': '♛',
      'rook': '♜',
      'bishop': '♝',
      'knight': '♞',
      'pawn': '♟'
    }
  };
  
  return symbols[piece.color][piece.type] || '';
}