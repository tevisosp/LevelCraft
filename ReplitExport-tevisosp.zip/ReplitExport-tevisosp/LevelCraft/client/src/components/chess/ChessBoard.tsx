import React from 'react';
import { ChessGameState, Piece, Position, PieceColor } from '../../lib/types/ChessTypes';

interface ChessBoardProps {
  gameState: ChessGameState;
  selectedSquare: string | null;
  validMoves: string[];
  onSquareClick: (position: Position) => void;
  currentPlayer: PieceColor;
}

export const ChessBoard: React.FC<ChessBoardProps> = ({
  gameState,
  selectedSquare,
  validMoves,
  onSquareClick,
  currentPlayer
}) => {
  const getPieceSymbol = (piece: Piece | null): string => {
    if (!piece) return '';
    
    const symbols = {
      'white': {
        'king': '♔',
        'queen': '♕',
        'rook': '♖',
        'bishop': '♗',
        'knight': '♘',
        'pawn': '♙'
      },
      'black': {
        'king': '♚',
        'queen': '♛',
        'rook': '♜',
        'bishop': '♝',
        'knight': '♞',
        'pawn': '♟'
      }
    };
    
    return symbols[piece.color][piece.type] || '';
  };

  const getSquareName = (row: number, col: number): string => {
    return `${String.fromCharCode(97 + col)}${8 - row}`;
  };

  const isSquareSelected = (row: number, col: number): boolean => {
    const squareName = getSquareName(row, col);
    return selectedSquare === squareName;
  };

  const isValidMove = (row: number, col: number): boolean => {
    const squareName = getSquareName(row, col);
    return validMoves.includes(squareName);
  };

  const isSquareLight = (row: number, col: number): boolean => {
    return (row + col) % 2 === 0;
  };

  const getSquareClasses = (row: number, col: number): string => {
    const baseClasses = 'w-16 h-16 flex items-center justify-center text-4xl cursor-pointer transition-all duration-200 relative';
    
    let colorClasses = '';
    if (isSquareLight(row, col)) {
      colorClasses = 'bg-amber-100 hover:bg-amber-200';
    } else {
      colorClasses = 'bg-amber-600 hover:bg-amber-700';
    }

    let statusClasses = '';
    if (isSquareSelected(row, col)) {
      statusClasses = 'ring-4 ring-blue-500 bg-blue-200';
    } else if (isValidMove(row, col)) {
      statusClasses = 'ring-2 ring-green-500';
    }

    // Check if king is in check
    const piece = gameState.board[row][col];
    if (piece && piece.type === 'king' && piece.color === currentPlayer && gameState.isCheck) {
      statusClasses += ' ring-4 ring-red-500 bg-red-200';
    }

    return `${baseClasses} ${colorClasses} ${statusClasses}`;
  };

  const handleSquareClick = (row: number, col: number) => {
    onSquareClick({ row, col });
  };

  return (
    <div className="bg-amber-800 p-6 rounded-lg shadow-2xl">
      {/* Column labels (a-h) */}
      <div className="flex justify-center mb-2">
        <div className="w-8"></div> {/* Spacer for row labels */}
        {[0, 1, 2, 3, 4, 5, 6, 7].map((col) => (
          <div key={col} className="w-16 text-center font-bold text-amber-100">
            {String.fromCharCode(97 + col)}
          </div>
        ))}
        <div className="w-8"></div> {/* Spacer */}
      </div>

      {/* Board with row labels */}
      <div className="flex">
        {/* Left row labels */}
        <div className="flex flex-col justify-center">
          {[0, 1, 2, 3, 4, 5, 6, 7].map((row) => (
            <div key={row} className="h-16 flex items-center justify-center w-8 font-bold text-amber-100">
              {8 - row}
            </div>
          ))}
        </div>

        {/* Chess board */}
        <div className="grid grid-cols-8 border-4 border-amber-900 rounded">
          {gameState.board.map((row, rowIndex) =>
            row.map((piece, colIndex) => (
              <div
                key={`${rowIndex}-${colIndex}`}
                className={getSquareClasses(rowIndex, colIndex)}
                onClick={() => handleSquareClick(rowIndex, colIndex)}
              >
                {/* Piece */}
                <div className="relative">
                  <span className="drop-shadow-lg text-4xl">
                    {getPieceSymbol(piece)}
                  </span>
                  
                  {/* Enhanced piece info */}
                  {piece && (
                    <div className="absolute -bottom-1 -right-1 bg-black bg-opacity-70 text-white text-xs rounded px-1">
                      <div className="flex flex-col items-center">
                        <span>💎{piece.value.toFixed(1)}</span>
                        {piece.age > 0 && (
                          <span className={piece.age > 5 ? 'text-red-300' : 'text-yellow-300'}>
                            ⏰{piece.age.toFixed(1)}
                          </span>
                        )}
                        {piece.capturesCount > 0 && (
                          <span className="text-green-300">⚔️{piece.capturesCount}</span>
                        )}
                        {piece.isRecruited && (
                          <span className="text-purple-300">🔄</span>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Valid move indicator */}
                {isValidMove(rowIndex, colIndex) && !piece && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-4 h-4 bg-green-500 rounded-full opacity-60"></div>
                  </div>
                )}

                {/* Capture indicator */}
                {isValidMove(rowIndex, colIndex) && piece && (
                  <div className="absolute inset-0 border-4 border-red-500 rounded opacity-60"></div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Right row labels */}
        <div className="flex flex-col justify-center">
          {[0, 1, 2, 3, 4, 5, 6, 7].map((row) => (
            <div key={row} className="h-16 flex items-center justify-center w-8 font-bold text-amber-100">
              {8 - row}
            </div>
          ))}
        </div>
      </div>

      {/* Bottom column labels */}
      <div className="flex justify-center mt-2">
        <div className="w-8"></div> {/* Spacer for row labels */}
        {[0, 1, 2, 3, 4, 5, 6, 7].map((col) => (
          <div key={col} className="w-16 text-center font-bold text-amber-100">
            {String.fromCharCode(97 + col)}
          </div>
        ))}
        <div className="w-8"></div> {/* Spacer */}
      </div>

      {/* Game status indicators */}
      <div className="mt-4 text-center">
        {gameState.isCheck && (
          <div className="bg-red-500 text-white px-4 py-2 rounded font-bold">
            ШАХ!
          </div>
        )}
        {gameState.isCheckmate && (
          <div className="bg-red-700 text-white px-4 py-2 rounded font-bold">
            МАТ!
          </div>
        )}
        {gameState.isStalemate && (
          <div className="bg-yellow-500 text-white px-4 py-2 rounded font-bold">
            ПАТ!
          </div>
        )}
      </div>
    </div>
  );
};