import React from 'react';
import { ChessGameState, PieceColor, Piece } from '../../lib/types/ChessTypes';

interface GameInfoPanelProps {
  gameState: ChessGameState;
  currentPlayer: PieceColor;
  capturedPieces: { white: Piece[]; black: Piece[] };
  onOfferGameEnd: () => void;
  onShowRecruitment: () => void;
  onStartNextGame?: () => void;
  isGameOver: boolean;
}

export const GameInfoPanel: React.FC<GameInfoPanelProps> = ({
  gameState,
  currentPlayer,
  capturedPieces,
  onOfferGameEnd,
  onShowRecruitment,
  onStartNextGame,
  isGameOver
}) => {
  const getPieceSymbol = (piece: Piece): string => {
    const symbols = {
      'white': {
        'king': '♔',
        'queen': '♕',
        'rook': '♖',
        'bishop': '♗',
        'knight': '♘',
        'pawn': '♙'
      },
      'black': {
        'king': '♚',
        'queen': '♛',
        'rook': '♜',
        'bishop': '♝',
        'knight': '♞',
        'pawn': '♟'
      }
    };
    return symbols[piece.color][piece.type] || '';
  };

  const getTotalPieceValue = (pieces: Piece[]): number => {
    return pieces.reduce((total, piece) => total + piece.value, 0);
  };

  const getPlayerDisplayName = (color: PieceColor): string => {
    return color === 'white' ? 'Белые' : 'Черные';
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 space-y-4">
      {/* Game Header */}
      <div className="text-center border-b pb-3">
        <h2 className="text-xl font-bold text-gray-800">
          Модифицированные Шахматы
        </h2>
        <p className="text-sm text-gray-600">
          Партия #{gameState.gameNumber} | Ход {gameState.fullMoveNumber}
        </p>
      </div>

      {/* Current Turn */}
      <div className="text-center">
        <div className={`inline-block px-4 py-2 rounded-lg ${
          currentPlayer === 'white' 
            ? 'bg-blue-100 text-blue-800' 
            : 'bg-gray-800 text-white'
        }`}>
          Ход: {getPlayerDisplayName(currentPlayer)}
        </div>
      </div>

      {/* Capital and Statistics */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-blue-50 p-3 rounded">
          <h3 className="font-semibold text-blue-800 mb-2">Белые</h3>
          <div className="space-y-1 text-sm">
            <div>💰 Капитал: {gameState.capital.white}</div>
            <div>🏆 Побед: {getTotalPieceValue(capturedPieces.white).toFixed(1)}</div>
          </div>
        </div>
        
        <div className="bg-gray-800 text-white p-3 rounded">
          <h3 className="font-semibold mb-2">Черные</h3>
          <div className="space-y-1 text-sm">
            <div>💰 Капитал: {gameState.capital.black}</div>
            <div>🏆 Побед: {getTotalPieceValue(capturedPieces.black).toFixed(1)}</div>
          </div>
        </div>
      </div>

      {/* Captured Pieces */}
      <div className="space-y-3">
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-1">Захваченные белыми:</h4>
          <div className="flex flex-wrap gap-1">
            {capturedPieces.white.length > 0 ? (
              capturedPieces.white.map((piece, index) => (
                <span key={index} className="text-lg" title={`Ценность: ${piece.value.toFixed(1)}`}>
                  {getPieceSymbol(piece)}
                </span>
              ))
            ) : (
              <span className="text-gray-400 text-sm">Нет</span>
            )}
          </div>
        </div>
        
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-1">Захваченные черными:</h4>
          <div className="flex flex-wrap gap-1">
            {capturedPieces.black.length > 0 ? (
              capturedPieces.black.map((piece, index) => (
                <span key={index} className="text-lg" title={`Ценность: ${piece.value.toFixed(1)}`}>
                  {getPieceSymbol(piece)}
                </span>
              ))
            ) : (
              <span className="text-gray-400 text-sm">Нет</span>
            )}
          </div>
        </div>
      </div>

      {/* Game Actions */}
      <div className="space-y-2 border-t pt-3">
        {!isGameOver && (
          <>
            <button
              onClick={onShowRecruitment}
              className="w-full px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded transition-colors"
            >
              🎯 Вербовка фигур
            </button>
            
            <button
              onClick={onOfferGameEnd}
              className="w-full px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded transition-colors"
            >
              🤝 Предложить окончить партию
            </button>
          </>
        )}

        {isGameOver && onStartNextGame && (
          <button
            onClick={onStartNextGame}
            className="w-full px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded transition-colors"
          >
            ▶️ Следующая партия
          </button>
        )}
      </div>

      {/* Game End Offer */}
      {gameState.gameEndOffered && !isGameOver && (
        <div className="bg-yellow-50 border border-yellow-200 p-3 rounded">
          <p className="text-sm text-yellow-800">
            {getPlayerDisplayName(gameState.gameEndOffered)} предлагает окончить партию
          </p>
        </div>
      )}

      {/* Enhanced Chess Rules Info */}
      <div className="bg-gray-50 p-3 rounded text-xs text-gray-600">
        <h4 className="font-semibold mb-2">Особые правила:</h4>
        <ul className="space-y-1">
          <li>• Фигуры стареют, если не двигаются</li>
          <li>• Старые фигуры не могут бить молодых того же ранга</li>
          <li>• Можно завербовать фигуры под боем за капитал</li>
          <li>• Активные фигуры становятся ценнее</li>
          <li>• Ветераны переходят в следующую партию</li>
        </ul>
      </div>
    </div>
  );
};