import React from 'react';
import { RecruitmentAction, PieceColor } from '../../lib/types/ChessTypes';

interface RecruitmentPanelProps {
  recruitmentOptions: RecruitmentAction[];
  currentPlayer: PieceColor;
  playerCapital: number;
  onRecruitPiece: (action: RecruitmentAction) => void;
  onClose: () => void;
}

export const RecruitmentPanel: React.FC<RecruitmentPanelProps> = ({
  recruitmentOptions,
  currentPlayer,
  playerCapital,
  onRecruitPiece,
  onClose
}) => {
  const getPieceSymbol = (type: string, color: PieceColor): string => {
    const symbols = {
      'white': {
        'king': '♔',
        'queen': '♕',
        'rook': '♖',
        'bishop': '♗',
        'knight': '♘',
        'pawn': '♙'
      },
      'black': {
        'king': '♚',
        'queen': '♛',
        'rook': '♜',
        'bishop': '♝',
        'knight': '♞',
        'pawn': '♟'
      }
    };
    return symbols[color][type as keyof typeof symbols.white] || '';
  };

  const getPieceDisplayName = (type: string): string => {
    const names = {
      'pawn': 'Пешка',
      'knight': 'Конь',
      'bishop': 'Слон',
      'rook': 'Ладья',
      'queen': 'Ферзь',
      'king': 'Король'
    };
    return names[type as keyof typeof names] || type;
  };

  const getSquareName = (row: number, col: number): string => {
    return `${String.fromCharCode(97 + col)}${8 - row}`;
  };

  return (
    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4 max-h-96 overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold text-gray-800">
            Вербовка фигур
          </h3>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-2xl"
          >
            ×
          </button>
        </div>

        <div className="mb-4 p-3 bg-blue-50 rounded">
          <p className="text-sm text-gray-700">
            Капитал игрока {currentPlayer === 'white' ? 'Белые' : 'Черные'}: 
            <span className="font-bold ml-1">{playerCapital}</span>
          </p>
          <p className="text-xs text-gray-600 mt-1">
            Можно завербовать только фигуры под боем
          </p>
        </div>

        {recruitmentOptions.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <p>Нет доступных фигур для вербовки</p>
            <p className="text-xs mt-2">Атакуйте вражеские фигуры, чтобы их завербовать</p>
          </div>
        ) : (
          <div className="space-y-2">
            {recruitmentOptions.map((option, index) => (
              <div
                key={index}
                className={`p-3 border rounded-lg ${
                  option.isAvailable 
                    ? 'border-green-300 bg-green-50 hover:bg-green-100' 
                    : 'border-gray-300 bg-gray-50'
                } transition-colors`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-3xl">
                      {getPieceSymbol(option.targetPiece.type, option.targetPiece.color)}
                    </span>
                    <div>
                      <div className="font-medium text-gray-800">
                        {getPieceDisplayName(option.targetPiece.type)}
                      </div>
                      <div className="text-sm text-gray-600">
                        Поле: {getSquareName(option.position.row, option.position.col)}
                      </div>
                      <div className="text-xs text-gray-500">
                        Возраст: {option.targetPiece.age.toFixed(1)} | 
                        Ценность: {option.targetPiece.value.toFixed(1)} |
                        Побед: {option.targetPiece.capturesCount}
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className={`font-bold ${option.isAvailable ? 'text-green-600' : 'text-red-600'}`}>
                      {option.cost} 💰
                    </div>
                    {option.isAvailable ? (
                      <button
                        onClick={() => onRecruitPiece(option)}
                        className="mt-1 px-3 py-1 bg-green-500 hover:bg-green-600 text-white text-sm rounded transition-colors"
                      >
                        Завербовать
                      </button>
                    ) : (
                      <div className="mt-1 text-xs text-red-600">
                        Не хватает капитала
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded transition-colors"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
};