import { useRef, useEffect } from 'react';
import { usePlayerStore } from '../../lib/stores/usePlayerStore';

interface PlayerProps {
  x: number;
  y: number;
  width: number;
  height: number;
}

const Player = ({ x, y, width, height }: PlayerProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { health, coins, score } = usePlayerStore();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw player as a simple colored rectangle
    ctx.fillStyle = '#4A90E2'; // Blue player
    ctx.fillRect(x, y, width, height);

    // Add simple face
    ctx.fillStyle = '#FFFFFF';
    // Eyes
    ctx.fillRect(x + width * 0.2, y + height * 0.2, width * 0.15, height * 0.15);
    ctx.fillRect(x + width * 0.65, y + height * 0.2, width * 0.15, height * 0.15);
    
    // Smile
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x + width * 0.5, y + height * 0.6, width * 0.2, 0, Math.PI);
    ctx.stroke();

  }, [x, y, width, height]);

  return (
    <canvas
      ref={canvasRef}
      width={width + 10}
      height={height + 10}
      style={{
        position: 'absolute',
        left: x - 5,
        top: y - 5,
        pointerEvents: 'none'
      }}
    />
  );
};

export default Player;
