import { useEffect, useRef, useState } from "react";
import { GameEngine } from "../../lib/game/GameEngine";
import { useGame } from "../../lib/stores/useGame";
import { useLevelStore } from "../../lib/stores/useLevelStore";
import { usePlayerStore } from "../../lib/stores/usePlayerStore";
import { useAudio } from "../../lib/stores/useAudio";
import { GameLevel } from "../../lib/types/GameTypes";

interface GameCanvasProps {
  levelId?: string | null;
  onBack: () => void;
}

const GameCanvas = ({ levelId, onBack }: GameCanvasProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameEngineRef = useRef<GameEngine | null>(null);
  const animationFrameRef = useRef<number>();
  
  const { phase, start, end, restart } = useGame();
  const { currentLevel, loadLevel } = useLevelStore();
  const { resetPlayer } = usePlayerStore();
  const { playHit, playSuccess } = useAudio();

  const [showInstructions, setShowInstructions] = useState(true);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Load level
    if (levelId) {
      loadLevel(levelId);
    } else {
      // Load default level if no level specified
      const defaultLevel: GameLevel = {
        id: 'default',
        name: 'Default Level',
        width: 800,
        height: 600,
        elements: [
          // Ground platforms
          { type: 'platform' as const, x: 0, y: 550, width: 200, height: 50, color: '#8B4513' },
          { type: 'platform' as const, x: 300, y: 450, width: 200, height: 50, color: '#8B4513' },
          { type: 'platform' as const, x: 600, y: 350, width: 200, height: 50, color: '#8B4513' },
          
          // Collectibles
          { type: 'coin' as const, x: 350, y: 400, width: 30, height: 30, color: '#FFD700' },
          { type: 'coin' as const, x: 650, y: 300, width: 30, height: 30, color: '#FFD700' },
          
          // Goal
          { type: 'goal' as const, x: 750, y: 250, width: 50, height: 100, color: '#00FF00' },
        ],
        playerStart: { x: 50, y: 500 }
      };
      useLevelStore.getState().setCurrentLevel(defaultLevel);
    }

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [levelId, loadLevel]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !currentLevel) return;

    // Initialize game engine
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    gameEngineRef.current = new GameEngine(ctx, currentLevel);

    // Set up event handlers
    gameEngineRef.current.onCollectCoin = () => {
      playHit();
    };

    gameEngineRef.current.onLevelComplete = () => {
      playSuccess();
      end();
    };

    gameEngineRef.current.onPlayerDeath = () => {
      end();
    };

    // Game loop
    const gameLoop = () => {
      if (gameEngineRef.current && phase === 'playing') {
        gameEngineRef.current.update();
        gameEngineRef.current.render();
      }
      animationFrameRef.current = requestAnimationFrame(gameLoop);
    };

    if (phase === 'playing') {
      gameLoop();
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [currentLevel, phase, playHit, playSuccess, end]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!gameEngineRef.current) return;

      switch (e.code) {
        case 'KeyA':
        case 'ArrowLeft':
          gameEngineRef.current.handleInput('left', true);
          break;
        case 'KeyD':
        case 'ArrowRight':
          gameEngineRef.current.handleInput('right', true);
          break;
        case 'KeyW':
        case 'ArrowUp':
        case 'Space':
          gameEngineRef.current.handleInput('jump', true);
          e.preventDefault();
          break;
        case 'KeyR':
          if (phase === 'ended') {
            handleRestart();
          }
          break;
        case 'Escape':
          onBack();
          break;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (!gameEngineRef.current) return;

      switch (e.code) {
        case 'KeyA':
        case 'ArrowLeft':
          gameEngineRef.current.handleInput('left', false);
          break;
        case 'KeyD':
        case 'ArrowRight':
          gameEngineRef.current.handleInput('right', false);
          break;
        case 'KeyW':
        case 'ArrowUp':
        case 'Space':
          gameEngineRef.current.handleInput('jump', false);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [phase, onBack]);

  const handleStart = () => {
    setShowInstructions(false);
    resetPlayer();
    start();
  };

  const handleRestart = () => {
    resetPlayer();
    if (gameEngineRef.current) {
      gameEngineRef.current.reset();
    }
    restart();
    setShowInstructions(false);
  };

  // Touch controls for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    const canvas = canvasRef.current;
    if (!canvas || !gameEngineRef.current) return;

    const rect = canvas.getBoundingClientRect();
    const x = touch.clientX - rect.left;
    const width = canvas.width;

    if (x < width * 0.3) {
      gameEngineRef.current.handleInput('left', true);
    } else if (x > width * 0.7) {
      gameEngineRef.current.handleInput('right', true);
    } else {
      gameEngineRef.current.handleInput('jump', true);
    }
  };

  const handleTouchEnd = () => {
    if (!gameEngineRef.current) return;
    gameEngineRef.current.handleInput('left', false);
    gameEngineRef.current.handleInput('right', false);
    gameEngineRef.current.handleInput('jump', false);
  };

  return (
    <div className="relative w-full h-full">
      <canvas
        ref={canvasRef}
        className="absolute inset-0"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        style={{ touchAction: 'none' }}
      />

      {/* Instructions overlay */}
      {showInstructions && phase === 'ready' && (
        <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center z-20">
          <div className="bg-white p-8 rounded-lg text-center max-w-md">
            <h2 className="text-2xl font-bold mb-4">Ready to Play!</h2>
            <p className="mb-4">
              Use <strong>WASD</strong> or <strong>Arrow Keys</strong> to move<br/>
              <strong>Space</strong> or <strong>W</strong> to jump<br/>
              Collect coins and reach the goal!
            </p>
            <p className="text-sm text-gray-600 mb-4">
              On mobile: Tap left/right sides to move, center to jump
            </p>
            <button
              onClick={handleStart}
              className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600"
            >
              Start Game
            </button>
          </div>
        </div>
      )}

      {/* Game over overlay */}
      {phase === 'ended' && (
        <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center z-20">
          <div className="bg-white p-8 rounded-lg text-center">
            <h2 className="text-2xl font-bold mb-4">
              {usePlayerStore.getState().levelComplete ? 'Level Complete!' : 'Game Over'}
            </h2>
            <div className="mb-4">
              <p>Score: {usePlayerStore.getState().score}</p>
              <p>Coins: {usePlayerStore.getState().coins}</p>
            </div>
            <div className="space-x-4">
              <button
                onClick={handleRestart}
                className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
              >
                Try Again (R)
              </button>
              <button
                onClick={onBack}
                className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
              >
                Back to Menu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Back button */}
      <button
        onClick={onBack}
        className="absolute top-4 left-4 z-10 bg-black bg-opacity-50 text-white p-2 rounded"
      >
        ← Back
      </button>
    </div>
  );
};

export default GameCanvas;
