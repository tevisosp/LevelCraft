import React from 'react';
import { GameElement } from '../../lib/types/GameTypes';

interface GameObjectProps {
  element: GameElement;
  ctx: CanvasRenderingContext2D;
}

export const renderGameObject = (element: GameElement, ctx: CanvasRenderingContext2D) => {
  const { type, x, y, width, height, color } = element;

  ctx.save();
  
  switch (type) {
    case 'platform':
      // Draw platform with wood-like texture effect
      ctx.fillStyle = color || '#8B4513';
      ctx.fillRect(x, y, width, height);
      
      // Add wood grain effect
      ctx.strokeStyle = '#654321';
      ctx.lineWidth = 1;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(x, y + (height / 4) * (i + 1));
        ctx.lineTo(x + width, y + (height / 4) * (i + 1));
        ctx.stroke();
      }
      break;

    case 'coin':
      // Draw spinning coin
      ctx.fillStyle = color || '#FFD700';
      ctx.beginPath();
      ctx.arc(x + width/2, y + height/2, width/2, 0, Math.PI * 2);
      ctx.fill();
      
      // Add inner circle
      ctx.fillStyle = '#FFA500';
      ctx.beginPath();
      ctx.arc(x + width/2, y + height/2, width/3, 0, Math.PI * 2);
      ctx.fill();
      
      // Add sparkle effect
      ctx.fillStyle = '#FFFF00';
      ctx.fillRect(x + width/2 - 1, y + height/4, 2, height/2);
      ctx.fillRect(x + width/4, y + height/2 - 1, width/2, 2);
      break;

    case 'obstacle':
      // Draw spiky obstacle
      ctx.fillStyle = color || '#FF4444';
      
      // Draw base
      ctx.fillRect(x, y + height/2, width, height/2);
      
      // Draw spikes
      const spikeCount = Math.floor(width / 20);
      ctx.beginPath();
      for (let i = 0; i < spikeCount; i++) {
        const spikeX = x + (width / spikeCount) * i;
        const spikeWidth = width / spikeCount;
        ctx.moveTo(spikeX, y + height/2);
        ctx.lineTo(spikeX + spikeWidth/2, y);
        ctx.lineTo(spikeX + spikeWidth, y + height/2);
      }
      ctx.fill();
      break;

    case 'goal':
      // Draw animated goal flag
      ctx.fillStyle = color || '#00FF00';
      
      // Flag pole
      ctx.fillRect(x + width - 10, y, 5, height);
      
      // Flag
      ctx.fillRect(x, y, width - 10, height/2);
      
      // Flag pattern
      ctx.fillStyle = '#FFFFFF';
      const squareSize = 8;
      for (let row = 0; row < Math.floor(height/2 / squareSize); row++) {
        for (let col = 0; col < Math.floor((width-10) / squareSize); col++) {
          if ((row + col) % 2 === 0) {
            ctx.fillRect(
              x + col * squareSize, 
              y + row * squareSize, 
              squareSize, 
              squareSize
            );
          }
        }
      }
      break;

    case 'enemy':
      // Draw simple enemy
      ctx.fillStyle = color || '#FF0000';
      ctx.fillRect(x, y, width, height);
      
      // Add angry eyes
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(x + width * 0.2, y + height * 0.2, width * 0.15, height * 0.15);
      ctx.fillRect(x + width * 0.65, y + height * 0.2, width * 0.15, height * 0.15);
      
      // Angry eyebrows
      ctx.fillStyle = '#000000';
      ctx.fillRect(x + width * 0.15, y + height * 0.1, width * 0.25, height * 0.1);
      ctx.fillRect(x + width * 0.6, y + height * 0.1, width * 0.25, height * 0.1);
      break;

    default:
      // Default rectangle
      ctx.fillStyle = color || '#888888';
      ctx.fillRect(x, y, width, height);
      break;
  }

  ctx.restore();
};

// React component version (for editor preview)
const GameObject: React.FC<GameObjectProps> = ({ element, ctx }) => {
  React.useEffect(() => {
    renderGameObject(element, ctx);
  }, [element, ctx]);

  return null;
};

export default GameObject;
